<?php
//database connections
$hostname = "localhost";
$user = "root";
$pass = "";
$database = "law";
//http://127.0.0.1/law/works/ajax/test/livesearch.php
$connection = mysql_connect($hostname, $user, $pass) or die(mysql_error());
mysql_select_db($database, $connection) or die(mysql_error());

echo $s = $_REQUEST["qsearch"];
echo'</br>';
echo $s2 = $_REQUEST["qsearch2"];
		
$output = "";
$s = str_replace(" ", "%", $s);
$query = "SELECT * FROM news WHERE newsContent LIKE '%" . $s . "%'";
echo  "sql_statemanet >>".$query ;
$squery = mysql_query($query);
if((mysql_num_rows($squery) != 0) && ($s != "")){

while($sLookup = mysql_fetch_array($squery)){
$newsID = $sLookup["newsID"];
$displayName = $sLookup["newsTitle"];
$newsContent = $sLookup["newsContent"];
$output .= '<li onclick="sendToSearch(\''.$newsID.'\')">'.$newsID.'</li>';
$output .= '<li onclick="sendToSearch(\''.$displayName.'\')">'.$displayName.'</li>';
$output .= '<li onclick="sendToSearch(\''.$newsContent.'\')">'.$newsContent.'</li>';
}
}

echo $output;
?>