 <div class='contx'>
		<div class='pagex'>
		<meta charset="utf-8">
				<style> 

    tr:nth-child(2n-1) {
             background-color: #aaa ;
             }
    tr:nth-child(2n) {
             background-color: #ccc ;
             } 
#mmx {text-align:center;} 
body
{
font-family:arial;
}
.preview
{
width:400px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
}     
</style>
    <link href="../../xtras/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="../../xtras/bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
	
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>

<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="jquery-1.4.2.min.js"></script>-->
<script type="text/javascript" src="../../xtras/bootstrap/js/jquery-1.4.2.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
$(".country").change(function(){
var id=$(this).val();
var dataString = 'id='+ id;

$.ajax
({
type: "POST",
url: "ajax_city.php",
data: dataString,
cache: false,
success: function(html)
{$(".city").html(html);} 
});

});
});
</script>




<?php 
//127.0.0.1/fra/works/ajax/insrt_rcd.php
//127.0.0.1/fra/works/ajax/insrt_rcd.php
//127.0.0.1/fra/works/ajax/ajaxinsert.php
 include('../../xtras/session.php');
include('../../xtras/config.php');
//$tbl=$login_session;

 echo"</br>";	
//echo"zanaty>>>>";
   ?>
   <!--<form id="imageform" method="post" enctype="multipart/form-data" action='ajaxinsert.php' dir='rtl'> -->
   <form  id="myform"  dir='rtl'> 
   
   <table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx'>
     <?
   $sql_gov=mysql_query("select gov_name,gov_name from tbl_gov");
   $sql_admins=mysql_query("select admin,admin from tbl_admins ");
   $sql_causes=mysql_query("select causes,causes from tbl_fault_causes ");
   $sql_dgree=mysql_query("select dgree,dgree from tbl_fault_dgree  ");
   $sql_eng=mysql_query("select eng_name,eng_name from tbl_engs  ");
   
   ?>
     <tr> <td width=10%> <label for ="title">  وصف العطل  :</label> </td>
   <td width=20%> <input type="text" id="dsc" name=" dsc" size="55"> </td> </tr>
   
     <tr> <td width=10%> <label for ="title"> خطورة العطل  :</label> </td>
   
   <td width=10%><select name="dgree" class="dgree">
<option selected="selected">--  اختار خطورة العطل --</option> 
       <? 
	    while($row = mysql_fetch_array($sql_dgree)){           
            $dgree=$row['dgree'];
            echo '<option value="'.$dgree.'">'.$dgree.'</option>';
        } ?></td>   </select>		</tr>   
		
     <tr> <td width=10%> <label for ="title">  المحافظة    :</label> </td>  
<td width=10%><input type='text' name="gov" class="gov" list='lkx'>
    <datalist id='lkx'>
       <? while($row = mysql_fetch_array($sql_gov)){ $gov_name=$row[0];
         ?><option value="<?=$gov_name;?>"><?=$gov_name;?></option><?}?>
	</datalist> </td></tr>
   
     <tr> <td width=10%> <label for ="title"> المدينة    :</label> </td>
   <td width=10%> <input type="text" id="city" name=" city" size="55"> </td> </tr>
   
     <tr> <td width=10%> <label for ="title"> حالة الخدمة     :</label> </td>
   <!--<td width=10%> <input type="text" id="stats" name=" stats" size="55"> </td> </tr>-->
   <td width=10%><select name="stats" class="stats">
<option selected="selected">--  اختار حالة الخدمه  --</option> 
         
           <option value="سقوط الخدمة">سقوط الخدمة </option>
		   <option value="الخدمة منقولة">الخدمة منقولة </option>
		   <option value="اتأثير علي الخدمة">لاتأثير علي الخدمة </option>
		   
       </td>   </select>		</tr>   
   
     <tr> <td width=10%> <label for ="title">   وحدة الأعمال المتأثرة :</label> </td>
   <td width=10%> <input type="text" id="downs" name=" downs" size="55"> </td> </tr>
   
     <tr> <td width=10%> <label for ="title"> الخدمة المتأثرة   :</label> </td>
   <td width=10%> <input type="text" id="affected" name=" affected"  size="55"> </td> </tr>
   
     <tr> <td width=10%> <label for ="title">  سبب العطل     :</label> </td>
      <td width=10%><select name="cause" class="cause">
<option selected="selected">--  اختار سبب العطل  --</option> 
       <? 
	    while($row = mysql_fetch_array( $sql_causes)){           
            $causes=$row['causes'];
            echo '<option value="'.$causes.'">'.$causes.'</option>';
        } ?></td>   </select>		</tr>
   
     <tr> <td width=10%> <label for ="title">  تاريخ بدايةالعطل     :</label> </td>
	    <td><div class="input-append date form_datetime">
<input size="55" type="text" value="" id="strt_flt" name="strt_flt"  readonly>
<span class="add-on"><i class="icon-th"></i></span>

</div></td></tr>
	 
   <!--<td width=10%> <input type="text" id="strt_flt" name=" strt_flt" size="55" > </td> </tr>-->
   
   
 <!-- <td> <div class="input-group date form_datetime col-md-5" data-date="1979-09-16T05:25:07Z" data-date-format="dd-mm-yyyy - HH:ii p" data-link-field="dtp_input1">
                    <input class="form-control" name=" strt_flt" size="55" type="text" value="" readonly>
                    <!--<span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>-->
					<!--<span class="input-group-addon"><span class="glyphicon glyphicon-th"></span></span>
                </div>
				 </td></tr>-->
				
   
   
   
   
   
   
     <tr> <td width=10%> <label for ="title">  تاريخ نهاية العطل      :</label> </td>
   <!--<td width=10%> <input type="text" id="end_flt" name=" end_flt" size="55" > </td> </tr>-->
   
   <TD><div class="input-append date form_datetime">
<input size="55" type="text" value="" id="end_flt" name=" end_flt"  readonly>
<span class="add-on"><i class="icon-th"></i></span>

</div></TD></TR>
<!-- differnve between stat date and end date
select strt_flt ,end_flt ,TIMEDIFF(end_flt,strt_flt) farq from tbl_fra where id=16401-->
      
   <TD width=10%><label for ="title">  الإدارة المسئوله  :</label></TD>
   <td width=10%><select name="admin" class="admin">
<option selected="selected">--اختار الاداره العامه --</option> 
       <? 
	    while($row = mysql_fetch_array($sql_admins))
        {           
            $admin=$row['admin'];
            echo '<option value="'.$admin.'">'.$admin.'</option>';
   } ?></td>   </select>		</tr>   

    <!-- <tr> <td width=10%> <label for ="title">  مهندس الورديه        :</label> </td>
   <td width=10%> <input type="text" id="eng" name=" eng"  size="55"> </td> </tr>-->
   
   
    <tr> <td width=10%> <label for ="title">  مهندس الورديه        :</label> </td>
<td width=10%> م / <input type='text' name="eng" class="eng" list='2kx'>
    <datalist id='2kx'>
       <? while($row = mysql_fetch_array($sql_eng)){ $eng_name=$row[0];
         ?><option value="<?=$eng_name;?>"><?=$eng_name;?></option><?}?>
	</datalist> </td></tr>
   
     <tr> <td width=10%> <label for ="title">  ملاحظات         :</label> </td>
   <td width=10%> <input type="text" id="comnt" name=" comnt" size="55" > </td> </tr>
   
    <!-- <tr> <td width=10%> <label for ="title"> ادخل البيانات     :</label> </td>
   <td width=10%> 
   <img src="../../xtras/img/ok.png" alt="Uploading...." name="photoimg" id="photoimg" height="15%" width="20%"/>
   </td> </tr> -->
   
   	<tr> <td width=10%> <label for ="title"> ادخل البيانات     :</label> </td>
       <td width=10px>
	   <!--<input type="submit" id="click2" value="...insert"  class='v11'  > -->
	       <input type="button" id="click2" value="...insert"   class='v11' > 
	   </td> </tr> 
			
		</table>
		
		
<div class='abx'></div>
	</form> 
		<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
     <script type="text/javascript">
     //alert('zanaty0');
 $(function(){$("form#myform").submit(function(){
			//alert('zanaty1');
		     $.ajax({type:"POST",data: $(this).serialize(),
                url: "../../works/ajax/ajaxinsert.php",
                success: function(msg){$(".abx").html(msg);}});
				return false;});
				
			 	
	});
	$('.v11').click(function(){
	//alert("mahmoud");
		 var a = confirm('هل ترغب فى ارسال البيانات');
		 if(a=='1'){
		$("form#myform").submit();
			
		}
 	});
 
  </script>	
<script type="text/javascript" src="../../xtras/bootstrap/js/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>




<script type="text/javascript">
  /*  $('.form_datetime').datetimepicker({
        
        weekStart: 1,
        todayBtn:  1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		forceParse: 0,
        showMeridian: 1
    });*/
	
</script>


 
<script type="text/javascript">
$(".form_datetime").datetimepicker({
format: "yyyy-mm-dd hh:ii"
});
</script>
