<?php
include('../../xtras/config.php');

if($_POST['gov']){
$gov=$_POST['gov'];
echo "<script type=\"text/javascript\"> alert(\" zanaty.$gov \");  </script>";
$stmnt=" select id,prblm_type,prblm_no  from tbl_problems  where  client_name like '%$gov%'";

 $sql=mysql_query($stmnt);

while($row=mysql_fetch_array($sql))
{
$id=$row['id'];
$data=$row['prblm_type'];
$prblm_no=$row['prblm_no'];
echo '<option value="'.$data.'">'.$id.','.$data.'</option>';
}
//echo"<input size=\"50%\" name=\"prblm_no\" type=\"text\" id=\"prblm_no\" value=\"" .$row['prblm_no']. "\">";
	echo "<script type=\"text/javascript\"> alert(\" $stmnt \");  </script>";
		
						
					
}

?>