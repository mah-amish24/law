<meta charset="utf-8">
<style> 
			 
#mmx {text-align:center;} 
body{font-family:arial;}
.preview
{width:400px;
border:solid 1px #dedede;
padding:10px;}
#preview
{color:#cc0000;
font-size:12px}     
</style>

<style type="text/css">
.myTable { width:70%; border-collapse:collapse;  }
.myTable td { padding:8px; border:#999 1px solid; }
 
.myTable tr:nth-child(even) { /*(even) or (2n 0)*/
	background: #A4D1FF;
}
.myTable tr:nth-child(odd) { /*(odd) or (2n 1)*/
	background: #EAF4FF;
}
</style>

<?php

//127.0.0.1/law/works/ajax/srch_prblm.php
include('../../xtras/config.php');
//$id = $_GET['id'];
     $sql=mysql_query("select id,client_name from tbl_problems");
    $result = mysql_query("select *  from tbl_problems   where id=2")
    or die(mysql_error());  

$row = mysql_fetch_assoc($result);?>
<!--<p>Description</p><br /><?php echo"<input name=\"pagedesc\" type=\"text\" id=\"pagedesc\" value=\"" .$row['types']. "\">"; ?>-->

<center>
   <table width='600px' cellpadding='2px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'>
   
      <tr> <td width='150px'> <label for ="title">  اسم الموكل   :</label> </td> 

<td width=10%><input type='text' name="country" class="country" list='lkx'>
    <datalist id='lkx'>
       <? while($row = mysql_fetch_array($sql)){
	   $id=$row[0];
	   $client_name=$row[1];
         ?><option value="<?=$client_name;?>"><?=$client_name;?></option><?}?>
	</datalist> 
      </td></tr>
   <tr><td width=10%><label> نوع القضيه </label></td> <td><select name="city" class="city">
<option selected="selected">--Select City--</option>
</select></td></tr>  
   
   
   <!-- <tr> <td width=23%> <label for ="title"><p> تصنيف القضايا:</p> </label> </td>  
   <td width=10%><?php echo"<input size=\"50%\" name=\"prblm_cls\" type=\"text\" id=\"prblm_cls\" value=\"" .$row['prblm_cls']. "\">"; ?></td>	</tr>
   
   <tr> <td width=23%> <label for ="title"><p>اسم الموكل :</p> </label> </td>  
   <td width=10%><?php echo"<input size=\"50%\" name=\"client_name\" type=\"text\" id=\"client_name\" value=\"" .$row['client_name']. "\">"; ?></td>	</tr>
   -->
  <!-- <tr> <td width=23%> <label for ="title"><p>اسم الخصم  :</p> </label> </td>  
   <td width=10%><?php echo"<input size=\"50%\" name=\"Opponent_name\" type=\"text\" id=\"Opponent_name\" value=\"" .$row['Opponent_name']. "\">"; ?></td>	</tr>
   
   <tr> <td width=23%> <label for ="title"><p>رقم القضيه   :</p> </label> </td>  
   <td width=10%><?php echo"<input size=\"50%\" name=\"prblm_no\" type=\"text\" id=\"prblm_no\" value=\"" .$row['prblm_no']. "\">"; ?></td>	</tr>
   
   <tr> <td width=23%> <label for ="title"><p>نوع القضيه    :</p> </label> </td>  
   <td width=10%><?php echo"<input size=\"50%\" name=\"prblm_type\" type=\"text\" id=\"prblm_type\" value=\"" .$row['prblm_type']. "\">"; ?></td>	</tr>
   -->
   <!--==============================================================================================-->
   <!--
     <tr> <td width=10%> <label for ="title">  ملاحظات         :</label> </td>
   <td width=10%><?php echo"<input size=\"50%\" name=\"cmnts\" type=\"text\" id=\"cmnts\" value=\"" .$row['cmnts']. "\">"; ?></td>	</tr>  
   	-->
		</table>
		
<script type="text/javascript" src="../../xtras/bootstrap/js/jquery.min.js"></script></script>
<script type="text/javascript">
$(document).ready(function(){
alert("zanaty");
$(".country").change(function(){
var id=$(this).val();
var dataString = 'gov='+ id;
alert(dataString);
$.ajax
({
type: "POST",
url: "ajax_city2.php",
data: dataString,
cache: false,
success: function(html)
{$(".city").html(html);} 
});

});
$(".city").change(function(){
var id=$(this).val();
var dataString = 'ct='+ id;
alert(dataString);
}

});
</script>