<meta charset="utf-8">
<?php
 include('../../xtras/session.php');
 include('../../xtras/config.php');
//C:\xampp\htdocs\fra\works\ajax\ajaxinsert.php
    //$dsc=$_POST['dsc'];
	$dgree=$_POST['dgree'];
	$gov=$_POST['country'];
	$city=$_POST['city'];
	
	echo $gov2=$_POST['country2'];
	echo $city2=$_POST['city2'];
	
	$stats=$_POST['stats'];
	$downs=$_POST['downs']="";
	$affected1=$_POST['affected1'];
	$affected2=$_POST['affected2'];
	$affected3=$_POST['affected3'];
	$affected4=$_POST['affected4'];
	$affected5=$_POST['affected5'];
	$affected6=$_POST['affected6'];
	$affected=$affected1.','.$affected2.','.$affected3.','.$affected4.','.$affected5.','.$affected6;
	$cause=$_POST['cause'];
	$strt_flt=$_POST['strt_flt'];
	$end_flt=$_POST['end_flt'];
	$admin=$_POST['admin'];
	$eng=$_POST['eng'];
	$Cmnts=$_POST['comnt'];
	$traffic=$_POST['traffic'];
	
	//$affected2 ="";
	 //$downs2 = $_POST['category'];
	 if(!$_POST['time']){
    //$time = $_POST['time'];
	 //if($time!=""){
	 $affected2 ="";
	 }
	 else if ($_POST['time']){
	 $affected2 = implode(",",$_POST['time']);
	 }
		//echo $downs2;
		//echo $affected2;
	//	echo "strt_flt>>".$strt_flt;
      // select dsc,types,gov,city,stats,downs,affected,cause,strt_flt,end_flt,admin,eng, Cmnts from tbl_fra 
				$dsc2=$cause." مابين محافظة  ".$gov." ومدينة ".$city." ,وبين محافظة ".$gov2." ومدينة ".$city2." نوع الربط ".$traffic;
$sql_statemanet = "INSERT INTO tbl_fra (types,from_gov,from_city,to_gov,to_city,traffic,stats,downs,affected,cause,strt_flt,end_flt,admin,eng, Cmnts) 
				              values ('$dgree','$gov','$city','$gov2','$city2','$traffic','$stats','$downs','$affected','$cause','$strt_flt','$end_flt','$admin','$eng', '$Cmnts') "  ;	
echo  "sql_statemanet >>".$sql_statemanet ;							  
								        mysql_query( $sql_statemanet);
	
 
   echo "<script> 
   alert(\" تمت عملية ادخال البيانات  بنجاح \");
   
      
   </script>";
		
?>
