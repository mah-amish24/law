<?
	$id = $_GET['id'];
	$t = $_GET['t'];
	$v= $_GET['v'];
	$tbl= $_GET['tbl'];
	//echo "<script type=\"text/javascript\">  alert(\" $tbl \"); alert(\" $id \"); alert(\" $t \"); alert(\" $v \"); </script>";  
	include('../../xtras/config.php');
	$st="update $tbl  set ".$t."='$v'  where id='$id'" ;
	mysql_query($st);
		echo "<script type=\"text/javascript\"> alert(\" frc update to $v \"); </script>";  		
						
	
?>