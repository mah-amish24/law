<meta charset="utf-8">
				<style> 

    tr:nth-child(2n-1) {
             background-color: #aaa ;
             }
    tr:nth-child(2n) {
             background-color: #ccc ;
             } 
#mmx {text-align:center;} 
body
{
font-family:arial;
}
.preview
{
width:400px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
}     
</style>
<?php
include('../../xtras/config.php');
$id = $_GET['id'];
//127.0.0.1/fra/works/ajax/get_data.php
// Get all the data from the "example" table
//$result = mysql_query("SELECT * FROM pages where pagekey = $key")
$result = mysql_query("select id,dsc,types,from_gov,from_city,to_gov,to_city,traffic,stats,downs,affected,cause,strt_flt
,end_flt,admin,Eng,Cmnts,TIMEDIFF(end_flt,strt_flt) farq  from tbl_fra  where id=$id")
    or die(mysql_error());  

$row = mysql_fetch_assoc($result);?>
<!--<p>Description</p><br /><?php echo"<input name=\"pagedesc\" type=\"text\" id=\"pagedesc\" value=\"" .$row['types']. "\">"; ?>-->

<center>
   <table width='500px' cellpadding='2px' cellspacing='2' border='1' dir='rtl' id='mmx'>
   
   
<tr> <td width=23%> <label for ="title"><p>وصف العطل  :</p> </label> </td>  
   <td width=10%><?php echo "<textarea name=\"pagecont\" cols=\"60\" rows=\"3\" id=\"pagecont\" >".$row['dsc']."</textarea>";?></td>	</tr>
   <!--<td width=10%><?php echo "<textarea name=\"dsc\" cols=\"120\" rows=\"20\" id=\"dsc\" value=\"" .$row['dsc']. "\">"; ?></td>	</tr>-->
<?php echo "</textarea>";?>
<tr> <td width=23%> <label for ="title"><p>خطورة العطل :</p> </label> </td>  
   <td width=10%><?php echo"<input size=\"50%\" name=\"types\" type=\"text\" id=\"types\" value=\"" .$row['types']. "\">"; ?></td>	</tr>   
   <!--==============================================================================================-->
   
     <tr> <td width=10%> <label for ="title">  بين محافظة    :</label> </td> 
<td width=10%><?php echo"<input size=\"50%\" name=\"from_gov\" type=\"text\" id=\"from_gov\" value=\"" .$row['from_gov']. "\">"; ?></td></tr>	 
      
  <tr><td> <label> ومدينة</label> </td>
<td><?php echo"<input size=\"50%\" name=\"from_city\" type=\"text\" id=\"from_city\" value=\"" .$row['from_city']. "\">"; ?></td>	</tr>  
   
     <tr> <td width=10%> <label for ="title">  الي محافظة    :</label> </td> 
<td width=50%><?php echo"<input size=\"50%\" name=\"to_gov\" type=\"text\" id=\"to_gov\" value=\"" .$row['to_gov']. "\">"; ?></td></tr>	 
      
  <tr><td> <label> ومدينة</label> </td>
<td><?php echo"<input size=\"50%\" name=\"to_city\" type=\"text\" id=\"to_city\" value=\"" .$row['to_city']. "\">"; ?></td>	</tr> 
<!--==============================================================================================-->
     <tr> <td width=10%> <label for ="title">   نوع الربط:</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"traffic\" type=\"text\" id=\"traffic\" value=\"" .$row['traffic']. "\">"; ?></td>	</tr>    
<!--==============================================================================================-->
        <tr> <td width=10%> <label for ="title"> حالة الخدمة     :</label> </td>   
   <td width=10%><?php echo"<input size=\"50%\" name=\"stats\" type=\"text\" id=\"stats\" value=\"" .$row['stats']. "\">"; ?></td>	</tr>  
   
     <tr> <td width=10%> <label for ="title">   وحدة الأعمال المتأثرة:</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"downs\" type=\"text\" id=\"downs\" value=\"" .$row['downs']. "\">"; ?></td>	</tr>  
   
      <tr> <td width=10%> <label for ="title"> الخدمة المتأثرة   :</label> </td>
   <td width=10%><?php echo"<input size=\"50%\" name=\"affected\" type=\"text\" id=\"affected\" value=\"" .$row['affected']. "\">"; ?></td>	</tr>  
   
     <tr> <td width=10%> <label for ="title">  سبب العطل     :</label> </td>
      <td width=10%><?php echo"<input size=\"50%\" name=\"cause\" type=\"text\" id=\"cause\" value=\"" .$row['cause']. "\">"; ?></td>	</tr>  
   
     <tr> <td width=10%> <label for ="title">  تاريخ بدايةالعطل     :</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"strt_flt\" type=\"text\" id=\"strt_flt\" value=\"" .$row['strt_flt']. "\">"; ?></td>	</tr>  


	 <tr> <td width=10%> <label for ="title">  تاريخ نهاية العطل      :</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"end_flt\" type=\"text\" id=\"end_flt\" value=\"" .$row['end_flt']. "\">"; ?></td>	</tr>  

	 <tr> <td width=10%> <label for ="title">  مدة العطل بالساعه:      :</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"farq\" type=\"text\" id=\"farq\" value=\"" .$row['farq']. "\">"; ?></td>	</tr>

<!-- differnve between stat date and end date
select strt_flt ,end_flt ,TIMEDIFF(end_flt,strt_flt) farq from tbl_fra where id=16401-->
      
   <TD width=10%><label for ="title">  الإدارة المسئوله  :</label></TD>
   <td width=10%><?php echo"<input size=\"50%\" name=\"admin\" type=\"text\" id=\"admin\" value=\"" .$row['admin']. "\">"; ?></td>	</tr>  

   <tr> <td width=10%> <label for ="title">  مهندس الورديه        :</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"Eng\" type=\"text\" id=\"Eng\" value=\"" .$row['Eng']. "\">"; ?></td>	</tr>  
   
     <tr> <td width=10%> <label for ="title">  ملاحظات         :</label> </td>
   <td width=10%><?php echo"<input size=\"50%\" name=\"Cmnts\" type=\"text\" id=\"Cmnts\" value=\"" .$row['Cmnts']. "\">"; ?></td>	</tr>  
   	
		</table>