<meta charset="utf-8">
<style>
	#jm input {border:0px;background:transparent;width:100%;}
	#mmx input {text-align:center;}
</style>
			<style> 

    .myTable tr:nth-child(2n-1) {
             background-color: #aaa ;
             }
    .myTable tr:nth-child(2n) {
             background-color: #ccc ;
             } 
#mmx {text-align:center;} 
body
{
font-family:arial;
}
.preview
{
width:400px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
} 
</style>
<?php
 include('../../xtras/session.php');
include('../../xtras/config.php');		
  
	$get_data="select * from tbl_cables  order by id desc";
	//127.0.0.1/fra/works/ajax/short_report.php
	 	  		$tbl="tbl_cables";
   ?>
    
     <table width='100%' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'> 
  <tr style="background-color: Gray ;">

  <td width='2%'> عرض   </td> 
  <!--<td width='2%'> م   </td> 
  <td width='2%'> id   </td> -->
  <td width='30%'> وصف العطل   </td> 
   <td width=8%>  تاريخ بدايةالعطل  </td>
  <td width=8%>  تاريخ نهاية العطل  </td>
  
   </tr> 
   
   <?
   $sql = mysql_query($get_data );
   $i=1;while($row = mysql_fetch_array($sql))  {
   $id = $row[0];  
   ?>
       <tr id='jm'class='x<?=$i;?>' onclick="$('.mgx').val('<?=$id;?>')" >
      <td> <a href="../works/ajax/get_data_cbl.php?id=<?=$id;?>"><img src="<?php echo '../xtras/img/plus-small.gif' ?>" width="12" height="9" alt="New Record" /></a></td>	   
   <!-- <td>
	<h2 onclick="$.ajax({url:'ajaxupdate.php',success: function(data){$('.get_db_table').html(data);}});""> 
	
	
	<img src="<?php echo '../../xtras/img/plus-small.gif' ?>" width="12" height="9" alt="New Record" /> </h2><td>-->	 
				 <!--<td >  <?=$i;?>   </td> 
                 <td >  <?=$id;?>   </td> -->				 
				<td><input size="100%" type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=desc&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[21];?>' ></td>
				
				<td><input size="25%" type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=Rec_date&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[3];?>' ></td>
				<td><input size="25%"type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=remv_date&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[7];?>' ></td>
								
	            </tr>
                <? $i++;}?> 
  </table>
     

   
   
   
   