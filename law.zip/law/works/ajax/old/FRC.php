<style>
	#jm input {border:0px;background:transparent;width:100%;}
	#mmx input {text-align:center;}
</style>
		<meta charset="utf-8">
				
    <style> 
	.myTable tr:nth-child(2n-1) { background-color: #aaa ; }
    .myTable tr:nth-child(2n) {  background-color: #ccc ;  }  </style> 



  <iframe name='ifrmx'  id='myframe'  frameborder='0' style='width:000px;height:000px;'></iframe>
  
   </br>
 <hr style='color:#FA3C00;border:1px solid #FA3C00;'> 
 </br>   
  <form  id="myform"  dir='rtl'> 
      <table width='100%' cellpadding='1px' cellspacing='2' border='1' dir='rtl' class='myTable' > 
<tr> 
<td>       اضغط علي وصف العطل المطلوب عمل انهاءه  </td>
<td>  <input size="25%" type='text' name ='id' class='mgx'></td>
   <TD><div class="input-append date form_datetime">
<input size="25%" type="text" value="" id="v" name="v"  readonly>
<span class="add-on"><i class="icon-th"></i></span>
</div></TD> 
 
 <td><input size="25%" type="button" id="click2" value="...insert"   class='v11' > 
	   </td> </tr> </table>
  </form>
  </br>
 <hr style='color:#FA3C00;border:1px solid #FA3C00;'> 
 </br>    
   
   <div class='abx'></div>
	</form> 
	<?
	$tbl='tbl_fra';
	  $t='end_flt';
	?>
		<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
     <script type="text/javascript">
     //alert('zanaty0');
 $(function(){$("form#myform").submit(function(){
			//alert('zanaty1');
		     $.ajax({type:"GET",data: $(this).serialize(),
                url: "../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&t=end_flt",
				success: function(msg){$(".abx").html(msg);}});
				return false;});
				
			 	
	});
	$('.v11').click(function(){
    //alert("mahmoud");
		 var a = confirm('هل ترغب فى ارسال البيانات');
		 if(a=='1'){
		$("form#myform").submit();
			
		}
 	});
 
  </script>	
   


    <link href="../../xtras/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="../../xtras/bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
<script type="text/javascript" src="../../xtras/bootstrap/js/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
 
<script type="text/javascript">
$(".form_datetime").datetimepicker({
format: "yyyy-mm-dd hh:ii"
});
</script>

 
 
 <?php
 include('../../xtras/session.php');
include('../../xtras/config.php');		
  
	$get_data="select * from tbl_fra   where end_flt = '0000-00-00 00:00:00'  order by id desc";
	 	  		
   ?>
    
     <table width='100%' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx'> 
  <tr style="background-color: Gray ;">  
  <td width='2%'> م   </td> 
  <td width='2%'> id   </td> 
  <td width='15%'> وصف العطل   </td> 
 
  <td width=8%>  تاريخ بدايةالعطل  </td>
  <td width=8%>  تاريخ نهاية العطل  </td>
  
   </tr> 
   
   <?
   $sql = mysql_query($get_data );
   $i=1;while($row = mysql_fetch_array($sql))  {
   $id = $row[0];  
   ?>
       <tr id='jm'class='x<?=$i;?>' onclick="$('.mgx').val('<?=$id;?>')" >  			
				 <td >  <?=$i;?>   </td> 
                 <td >  <?=$id;?>   </td> 				 
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=desc&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[1];?>' ></td>
				
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=strt_flt&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[12];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=end_flt&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[13];?>' ></td>
								
	            </tr>
                <? $i++;}?> 
  </table>
     

   
   
   
   