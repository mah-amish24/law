<style>
	#jm input {border:0px;background:transparent;width:100%;}
	#mmx input {text-align:center;}
</style>

 <?php
 include('../../xtras/session.php');
include('../../xtras/config.php');		
$tbl='tbl_fra';
  /*$tbl=$login_session;
 
	 $in_date=$_POST['ajax_date'];
	 $out_date=$_POST['outdate'];
	        
			 $get_data="select *  from ".$tbl." where in_date='$out_date' ";
			 
			*/ 
  
	$get_data="select *  from tbl_fra  order by id desc";
	 //echo "<script> alert(\" $get_data \");</script>";	  		
   ?>
    
     <table width='100%' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx'> 
  <tr style="background-color: Gray ;">  
  <td width='2%'> م   </td> 
  <td width='15%'> وصف العطل   </td> 
  <td width='4%'> النوع   </td> 
  <td width=5%> بين محافظة  </td>
  <td width=5%> ومدينة  </td>
  <td width=5%> ومحافظة  </td>
  <td width=5%> ومدينة  </td>
  <td width=5%> نوع الربط  </td>  
  <td width=15%> حالة الخدمه  </td>
  <td width=5%>  وحدة الأعمال المتأثرة  </td>
  <td width=15%>  الخدمة المتأثرة  </td>
  <td width=15%> سبب العطل  </td>
  <td width=8%>  تاريخ بدايةالعطل  </td>
  <td width=8%>  تاريخ نهاية العطل  </td>
  <td width=10%>  الإدارة المسئوله  </td>
  <td width=10%> مهندس الورديه  </td>
  <td width=10%> ملاحظات :  </td>  
   </tr> 
   
   <?
   $sql = mysql_query($get_data );
   $i=1;while($row = mysql_fetch_array($sql))  {
   $id = $row[0];  
   ?>
       <tr id='jm'class='x<?=$i;?>' >   			
				 <td >  <?=$i;?>   </td>                
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=desc&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[1];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=type&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[2];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=from_gov&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[3];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=from_city&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[4];?>' ></td>
				
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=to_gov&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[5];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=to_city&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[6];?>' ></td>
				
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=downs&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[7];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=stats&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[8];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=affected&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[9];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=cause&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[10];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=strt_flt&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[11];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=end_flt&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[12];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=admin&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[13];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=Eng&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[14];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=Comments&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[15];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=Comments&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[16];?>' ></td>
				</td>
	            </tr>
                <? $i++;}?> 
  </table>

  	
   
   
   
   