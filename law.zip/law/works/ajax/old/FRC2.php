<style>
	#jm input {border:0px;background:transparent;width:100%;}
	#mmx input {text-align:center;}
</style>
		<meta charset="utf-8">
				
    <style> tr:nth-child(2n-1) { background-color: #aaa ; }
    tr:nth-child(2n) {  background-color: #ccc ;  }  </style> 

    
   
   
   
   <TD><div class="input-append date form_datetime">
<input size="55" type="text" value="" id="end_flt" name=" end_flt"  readonly>
<span class="add-on"><i class="icon-th"></i></span>
</div></TD>

    <link href="../../xtras/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="../../xtras/bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
<script type="text/javascript" src="../../xtras/bootstrap/js/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
 
<script type="text/javascript">
$(".form_datetime").datetimepicker({
format: "yyyy-mm-dd hh:ii"
});
</script>



<hr style='color:#FA3C00;border:1px solid #FA3C00;'> 
<p id='e4'>مركز تحميل الصور</p>
<br>
  <iframe name='ifrmx'  id='myframe'  frameborder='0' style='width:000px;height:000px;'></iframe>
  <form action="upload2.php"  id='frmx' target='ifrmx' method="post" enctype="multipart/form-data">
      <table width='100%' cellpadding='1px' cellspacing='2' border='1' dir='rtl' > 
<tr> 
<td> اضغط علي البضاعه المراد رفع صوره لها </td>
<td>  <input type='text' name ='hid' class='mgx'></td>
 <td> <div  style="width:50px;height:35px;background:url('img/camera.png') no-repeat;background-size:50px 35px;float:left;">
					<input onchange="$('#frmx').submit();"  
					type="file" name="files[]" multiple="multiple" class='oky' accept="*/*" style="position: relative;width:100px;text-align:right;-moz-opacity:0;filter:alpha(opacity: 0);opacity:0;z-index:2;">
					</td></div>
					</table>
  </form>
  </br>
 <hr style='color:#FA3C00;border:1px solid #FA3C00;'> 
 </br>
 
 
 <?php
 include('../../xtras/session.php');
include('../../xtras/config.php');		
  
	$get_data="select *  from tbl_fra  order by id desc";
	 	  		
   ?>
    
     <table width='100%' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx'> 
  <tr style="background-color: Gray ;">  
  <td width='2%'> م   </td> 
  <td width='2%'> id   </td> 
  <td width='15%'> وصف العطل   </td> 
 <!-- <td width='4%'> النوع   </td> 
  <td width=5%> بين محافظة  </td>
  <td width=5%> ومدينة  </td>
  <td width=5%> ومحافظة  </td>
  <td width=5%> ومدينة  </td>
  <td width=15%> حالة الخدمه  </td>
  <td width=5%>  وحدة الأعمال المتأثرة  </td>
  <td width=15%>  الخدمة المتأثرة  </td>
  <td width=15%> سبب العطل  </td>-->
  <td width=8%>  تاريخ بدايةالعطل  </td>
  <td width=8%>  تاريخ نهاية العطل  </td>
  <!--<td width=10%>  الإدارة المسئوله  </td>
  <td width=10%> مهندس الورديه  </td>
  <td width=10%> ملاحظات :  </td> -->
   </tr> 
   
   <?
   $sql = mysql_query($get_data );
   $i=1;while($row = mysql_fetch_array($sql))  {
   $id = $row[0];  
   ?>
       <tr id='jm'class='x<?=$i;?>' onclick="$('.mgx').val('<?=$id;?>')" >  			
				 <td >  <?=$i;?>   </td> 
                 <td >  <?=$id;?>   </td> 				 
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=desc&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[1];?>' ></td>
				<!--<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=type&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[2];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=from_gov&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[3];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=from_city&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[4];?>' ></td>
				
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=to_gov&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[5];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=to_city&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[6];?>' ></td>
				
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=downs&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[7];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=stats&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[8];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=affected&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[9];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=cause&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[10];?>' ></td>
				--><td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=strt_flt&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[11];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=end_flt&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[12];?>' ></td>
				
				   <TD><div class="input-append date form_datetime">
                   <input size="55" type="text" value="" id="end_flt" name=" end_flt"  readonly>
                  <span class="add-on"><i class="icon-th"></i></span></div></TD>
				
				
				
				<!--<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=admin&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[13];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=Eng&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[14];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=Comments&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[15];?>' ></td>
				--></td>
	            </tr>
                <? $i++;}?> 
  </table>
     

   
   
   
   