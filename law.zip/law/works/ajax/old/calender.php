		<meta charset="utf-8">
				
   <!-- <style> tr:nth-child(2n-1) { background-color: #aaa ; }
    tr:nth-child(2n) {  background-color: #ccc ;  }  </style> 
	127.0.0.1/law/works/ajax/calender.php
	
	-->

    
   
   
   
   <TD><div class="input-append date form_datetime">
<input size="55" type="text" value="" id="end_flt" name=" end_flt"  readonly>
<span class="add-on"><i class="icon-th"></i></span>
</div></TD>

    <link href="../../xtras/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="../../xtras/bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
<script type="text/javascript" src="../../xtras/bootstrap/js/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
 
<script type="text/javascript">
$(".form_datetime").datetimepicker({
format: "yyyy-mm-dd"
<!--format: "yyyy-mm-dd hh:ii"-->
});
</script>

