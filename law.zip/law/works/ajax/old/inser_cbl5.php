 <div class='contx'>
		<div class='pagex'>
		<meta charset="utf-8">
				<style> 

   .myTable tr:nth-child(2n-1) {
             background-color: #aaa ;
             }
   .myTable tr:nth-child(2n) {
             background-color: #ccc ;
             } 
#mmx {text-align:center;} 
body
{
font-family:arial;
}
.preview
{
width:400px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
}     
</style>
   <!-- <link href="../../xtras/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="../../xtras/bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
	
	
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>-->



<?php 
//127.0.0.1/law/works/ajax/inser_cbl5.php


 include('../../xtras/session.php');
include('../../xtras/config.php');
echo '</br>';

   ?>
   
   <center>
   <form  id="myform"  dir='rtl'> 
   
   <table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'>
     <?   $sql_gov=mysql_query("select id,gov_name from tbl_gov");       ?>
   
   <tr> <td width='150px'> <label for ="title">   تصنيف القضايا   :</label> </td>
   <td width=10%><select name="prblm_cls" class="prblm_cls">
         <option selected="selected">-اختار تصنيف القضايا-</option>
           <option value="tbl_problem_family">أسره   </option>
		   <option value="tbl_problem_msdmnr"> جنح   </option>
           <option value="tbl_problem_civil"> مدني  </option>   
		          </td>   </select>		</tr> 
				  
<td width='150px'><label for ="title">  نوع القضيه   :</label></TD>
   <td width=10%> <select name="prblm_type" class="prblm_type"> 
<option selected="selected">- اختار نوع القضيه-</option>

  </td> </tr> 
   
    <tr> <td width='150px'> <label for ="title">  اسم الموكل   :</label> </td>   
     <td width=30%> <input type="text" id="Flt_cause" name=" Flt_cause" size="55">    </TD></TR>
	   
     <tr> <td width='150px'> <label for ="title">  اسم الخصم   :</label> </td>   
     <td width=30%> <input type="text" id="down" name=" down" size="55" >    </TD></TR>
	 
	 <tr> <td width='150px'> <label for ="title">  رقم القضيه   :</label> </td>   
     <td width=30%> <input type="text" id="clnt" name=" clnt" size="25"  >     </TD></TR>
	
   <tr> <td width='150px'> <label for ="title">  تاريخ الجلسه اول درجه    :</label> </td>   
     <td width=30%> <input type="text" id="Flt_cause" name=" Flt_cause" size="55" >
<input type="text" size="12" id="inputField" />	 </TD></TR>
	 
	 
	 <tr> <td width='150px'> <label for ="title"> رقم الاستئناف     :</label> </td>   
     <td width=30%> <input type="text" id="Flt_cause" name=" Flt_cause" size="55">    </TD></TR>
	 
	 <tr> <td width='150px'> <label for ="title"> تاريخ جلسة الاستئناف      :</label> </td>   
     <td width=30%> <input type="text" id="Flt_cause" name=" Flt_cause" size="55">    </TD></TR>
	 
   
     <tr> <td width='150px'> <label for ="title">  ملاحظات         :</label> </td>
   <td width=30%> <input type="text" id="cmnts" name="cmnts" size="55">    </TD></TR>
   <tr> <td width='150px'> <label for ="title">  ملاحظات         :</label> </td> <td width=30%><input type="text" size="12" id="inputField" /> </TD></TR>
  
   	<tr> <td width='150px'> <label for ="title"> ادخل البيانات     :</label> </td>
       <td width=10px>
	   
	       <input type="button" id="click2" value="...insert"   class='v11' > 
	   </td> </tr> 
			
		</table>
		
		
		
		
		
<div class='abx'></div>
	</form> 
	
	
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" />
<script type="text/javascript" src="jquery.1.4.2.js"></script>
<script type="text/javascript" src="jsDatePick.jquery.min.1.3.js"></script>
<script type="text/javascript">
	window.onload = function(){
		new JsDatePick({
			useMode:2,
			target:"inputField",
			dateFormat:"%d-%M-%Y"			
		});
	};
	
</script>


		<!--<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>-->
		<script src="../../xtras/bootstrap/js/jquery-1.11.0.min.js"></script>
     <script type="text/javascript">
     //alert('zanaty0');
 $(function(){$("form#myform").submit(function(){
			//alert('zanaty1');
		     $.ajax({type:"POST",data: $(this).serialize(),
                url: "../../works/ajax/ajaxinst_cbl.php",
                success: function(msg){$(".abx").html(msg);}});
				return false;});
				
			 	
	});
	$('.v11').click(function(){
	//alert("mahmoud");
		 var a = confirm('هل ترغب فى ارسال البيانات');
		 if(a=='1'){
		$("form#myform").submit();
			
		}
 	});
 
  </script>	
<!--<script type="text/javascript" src="../../xtras/bootstrap/js/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
 
<script type="text/javascript">
$(".form_datetime").datetimepicker({
format: "yyyy-mm-dd hh:ii"
});
</script>-->

<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>-->
<script type="text/javascript" src="../../xtras/bootstrap/js/jquery.min.js"></script></script>
<script type="text/javascript">
$(document).ready(function(){
//alert("zanaty");
$(".prblm_cls").change(function(){
var id=$(this).val();
var dataString = 'prblm_cls='+ id;
//alert(dataString);
$.ajax
({
type: "POST",
url: "ajax_city.php",
data: dataString,
cache: false,
success: function(html)
{$(".prblm_type").html(html);} 
});

});

});
</script>