<meta charset="utf-8">
				<style> 

   <!-- .myTable tr:nth-child(2n-1) {
             background-color: #aaa ;
             }
    .myTable tr:nth-child(2n) {
             background-color: #ccc ;
             } 
			 127.0.0.1/fra/works/ajax/get_data_cbl.php
			 -->
			 
#mmx {text-align:center;} 
body
{
font-family:arial;
}
.preview
{
width:400px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
}     
</style>

<style type="text/css">
.myTable { width:70%; border-collapse:collapse;  }
.myTable td { padding:8px; border:#999 1px solid; }
 
.myTable tr:nth-child(even) { /*(even) or (2n 0)*/
	background: #A4D1FF;
}
.myTable tr:nth-child(odd) { /*(odd) or (2n 1)*/
	background: #EAF4FF;
}
</style>
<a href="<?= $previous ?>">Back</a>

<?php
//echo "<a href=\"javascript:history.go(-1)\">GO BACK</a>";
$previous = "javascript:history.go(-1)";
if(isset($_SERVER['HTTP_REFERER'])) {
    $previous = $_SERVER['HTTP_REFERER'];
}



include('../../xtras/config.php');
$id = $_GET['id'];

$result = mysql_query("select Flt_type,join_type,flt_acause,Rec_date,mov_date,arrival_date,arrival_time,remv_date,Flt_place,Flt_cause,down
,clnt,prgress,admin,EngRec,cmnt,TIMEDIFF(remv_date,Rec_date) farq ,dsc,from_gov,to_gov,Cable_path_from,Cable_path_to,EngRec,cmnt   from tbl_cables  where id=$id")
    or die(mysql_error());  

$row = mysql_fetch_assoc($result);?>
<!--<p>Description</p><br /><?php echo"<input name=\"pagedesc\" type=\"text\" id=\"pagedesc\" value=\"" .$row['types']. "\">"; ?>-->

<center>
   <table width='600px' cellpadding='2px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'>
   
   
<tr> <td width=30%> <label for ="title"><p>وصف العطل  :</p> </label> </td>  
   <td width=10%><?php echo "<textarea name=\"pagecont\" cols=\"60\" rows=\"3\" id=\"pagecont\" >".$row['dsc']."</textarea>";?></td>	</tr>
   <!--<td width=10%><?php echo "<textarea name=\"dsc\" cols=\"120\" rows=\"20\" id=\"dsc\" value=\"" .$row['dsc']. "\">"; ?></td>	</tr>-->
<?php echo "</textarea>";?>
    <tr> <td width=23%> <label for ="title"><p> تصنيف الكابل:</p> </label> </td>  
   <td width=10%><?php echo"<input size=\"50%\" name=\"Flt_type\" type=\"text\" id=\"Flt_type\" value=\"" .$row['Flt_type']. "\">"; ?></td>	</tr>
   
   <tr> <td width=23%> <label for ="title"><p>نوع الربط :</p> </label> </td>  
   <td width=10%><?php echo"<input size=\"50%\" name=\"join_type\" type=\"text\" id=\"join_type\" value=\"" .$row['join_type']. "\">"; ?></td>	</tr>
   
   <tr> <td width=23%> <label for ="title"><p>نوع العطل :</p> </label> </td>  
   <td width=10%><?php echo"<input size=\"50%\" name=\"flt_acause\" type=\"text\" id=\"flt_acause\" value=\"" .$row['flt_acause']. "\">"; ?></td>	</tr>
   
   <!--==============================================================================================-->
   
     <tr> <td width=10%> <label for ="title">  بين محافظة    :</label> </td> 
<td width=10%><?php echo"<input size=\"50%\" name=\"from_gov\" type=\"text\" id=\"from_gov\" value=\"" .$row['from_gov']. "\">"; ?></td></tr>	 
      
  <tr><td> <label> ومدينة</label> </td>
<td><?php echo"<input size=\"50%\" name=\"Cable_path_from\" type=\"text\" id=\"Cable_path_from\" value=\"" .$row['Cable_path_from']. "\">"; ?></td>	</tr>  
   
     <tr> <td width=10%> <label for ="title">  الي محافظة    :</label> </td> 
	 <td width=10%><?php echo"<input size=\"50%\" name=\"to_gov\" type=\"text\" id=\"to_gov\" value=\"" .$row['to_gov']. "\">"; ?></td></tr>
      
  <tr><td> <label> ومدينة</label> </td>
<td width=50%><?php echo"<input size=\"50%\" name=\"Cable_path_to\" type=\"text\" id=\"Cable_path_to\" value=\"" .$row['Cable_path_to']. "\">"; ?></td></tr>
<!--==============================================================================================-->
     <tr> <td width=10%> <label for ="title">   وقت استلام العطل:</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"Rec_date\" type=\"text\" id=\"Rec_date\" value=\"" .$row['Rec_date']. "\">"; ?></td>	</tr>    
<!--==============================================================================================-->
        <tr> <td width=10%> <label for ="title"> وقت التحرك	:</label> </td>   
   <td width=10%><?php echo"<input size=\"50%\" name=\"mov_date\" type=\"text\" id=\"mov_date\" value=\"" .$row['mov_date']. "\">"; ?></td>	</tr>  
   
     <tr> <td width=10%> <label for ="title">   وقت الوصول:</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"arrival_date\" type=\"text\" id=\"arrival_date\" value=\"" .$row['arrival_date']. "\">"; ?></td>	</tr>  
   
      <tr> <td width=10%> <label for ="title"> زمن الوصول (60 كم /س)   :</label> </td>
   <td width=10%><?php echo"<input size=\"50%\" name=\"arrival_time\" type=\"text\" id=\"arrival_time\" value=\"" .$row['arrival_time']. "\">"; ?></td>	</tr>
  
      <tr> <td width=10%> <label for ="title"> زمن ازالة العطل  :</label> </td>
   <td width=10%><?php echo"<input size=\"50%\" name=\"remv_date\" type=\"text\" id=\"remv_date\" value=\"" .$row['remv_date']. "\">"; ?></td>	</tr>

      	 <tr> <td width=10%> <label for ="title">  مدة  ازالة العطل :      :</label> </td>
         <td width=10%><?php echo"<input size=\"50%\" name=\"farq\" type=\"text\" id=\"farq\" value=\"" .$row['farq']. "\">"; ?></td>	</tr>
  
   
     <tr> <td width=10%> <label for ="title">  سبب العطل     :</label> </td>
      <td width=10%><?php echo"<input size=\"50%\" name=\"Flt_cause\" type=\"text\" id=\"Flt_cause\" value=\"" .$row['Flt_cause']. "\">"; ?></td>	</tr>  

	  


   
     <tr> <td width=10%> <label for ="title">  مكان العطل     :</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"Flt_place\" type=\"text\" id=\"Flt_place\" value=\"" .$row['Flt_place']. "\">"; ?></td>	</tr>  


	 <tr> <td width=10%> <label for ="title">  العطل وسببه      :</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"Flt_cause\" type=\"text\" id=\"Flt_cause\" value=\"" .$row['Flt_cause']. "\">"; ?></td>	</tr> 

	 <tr> <td width=10%> <label for ="title">  الخدمة المتاثرة بالعطل      :</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"down\" type=\"text\" id=\"down\" value=\"" .$row['down']. "\">"; ?></td>	</tr> 

	 <tr> <td width=10%> <label for ="title">  العميل      :</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"clnt\" type=\"text\" id=\"clnt\" value=\"" .$row['clnt']. "\">"; ?></td>	</tr> 

	 <tr> <td width=10%> <label for ="title">  ما تم انجازه      :</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"prgress\" type=\"text\" id=\"prgress\" value=\"" .$row['prgress']. "\">"; ?></td>	</tr> 


<!-- differnve between stat date and end date
select strt_flt ,end_flt ,TIMEDIFF(end_flt,strt_flt) farq from tbl_fra where id=16401-->
      
   <TD width=10%><label for ="title">  الإدارة المسئوله  :</label></TD>
   <td width=10%><?php echo"<input size=\"50%\" name=\"admin\" type=\"text\" id=\"admin\" value=\"" .$row['admin']. "\">"; ?></td>	</tr>  

   <tr> <td width=10%> <label for ="title">  مستلم العطل        :</label> </td>
<td width=10%><?php echo"<input size=\"50%\" name=\"EngRec\" type=\"text\" id=\"EngRec\" value=\"" .$row['EngRec']. "\">"; ?></td>	</tr>  
   
     <tr> <td width=10%> <label for ="title">  ملاحظات         :</label> </td>
   <td width=10%><?php echo"<input size=\"50%\" name=\"cmnt\" type=\"text\" id=\"cmnt\" value=\"" .$row['cmnt']. "\">"; ?></td>	</tr>  
   	
		</table>