 <!--<div class='contx'>
		<div class='pagex'>-->
		<meta charset="utf-8">
				<style> 

    .myTable tr:nth-child(2n-1) {background-color: #aaa ; } 
	.myTable tr:nth-child(2n)  { background-color: #ccc ;
             } 
#mmx {text-align:center;} 
body
{
font-family:arial;
}
.preview
{
width:400px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
}     
</style>
    <link href="../xtras/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="../xtras/bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
	
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>



<?php 
//127.0.0.1/fra/works/ajax/insrt_rcd.php
 include('../../xtras/session.php');
include('../../xtras/config.php');
//$tbl=$login_session;

 echo"</br>";	
//echo"zanaty>>>>";
   ?>
   <!--<form id="imageform" method="post" enctype="multipart/form-data" action='ajaxinsert.php' dir='rtl'> -->
   
    <? //echo '<span style="background-color:yellow;">background color2</span>';  ?>
   
   <form  id="myform"  dir='rtl'> 
   
   <table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'>
     <?
   $sql_gov=mysql_query("select id,gov_name from tbl_gov");
   $sql_admins=mysql_query("select admin,admin from tbl_admins ");
   $sql_causes=mysql_query("select causes,causes from tbl_fault_causes ");
   $sql_dgree=mysql_query("select dgree,dgree from tbl_fault_dgree  ");
   $sql_eng=mysql_query("select eng_name,eng_name from tbl_engs  ");
   $sql=mysql_query("select id,gov_name from tbl_gov");
   
   ?>
    <!-- <tr> <td width=10%> <label for ="title">  وصف العطل  :</label> </td>
   <td width=20%> <input type="text" id="dsc" name=" dsc" size="55"> </td> </tr>-->
<tr> <td width=10%> <label for ="title"><p>خطورة العطل </p> :</label> </td>
   
   <td width=10%><select name="dgree" class="dgree">
<option selected="selected">--  اختار خطورة العطل --</option> 
<option><span style="background:red;">One</span></option>
<? echo '<span style="background-color:yellow;">background color3</span>';  ?>
<? 
   
	    while($row = mysql_fetch_array($sql_dgree)){           
            $dgree=$row['dgree'];
            echo '<option value="'.$dgree.'">'.$dgree.'</option>';
        } ?></td>   </select>		</tr>   
   <!--==============================================================================================-->
   
     <tr> <td width=10%> <label for ="title">  بين محافظة    :</label> </td> 

<td width=10%><input type='text' name="country" class="country" list='lkx'>
    <datalist id='lkx'>
       <? while($row = mysql_fetch_array($sql_gov)){
	   $id=$row[0];
	   $gov_name=$row[1];
         ?><option value="<?=$gov_name;?>"><?=$gov_name;?></option><?}?>
	</datalist> 
      
   <label> ومدينة</label> <select name="city" class="city">
<option selected="selected">--Select City--</option>
</select></td></tr>
   
        <tr> <td width=10%> <label for ="title">  الي محافظة    :</label> </td> 

<td width=10%><input type='text' name="country2" class="country2" list='lkx'>
    <datalist id='lkx'>
       <? while($row = mysql_fetch_array($sql_gov)){
	   $id=$row[0];
	   $gov_name=$row[1];
         ?><option value="<?=$gov_name;?>"><?=$gov_name;?></option><?}?>
	</datalist> 
      
   <label>ومدينة</label> <select name="city2" class="city2">
<option selected="selected">--Select City--</option>
</select></td></tr>
<!--==============================================================================================-->
     <tr> <td width=10%> <label for ="title">   نوع الربط:</label> </td>
   <td width=10%><select name="traffic" class="traffic">
<option selected="selected">-- اختار نوع الربط  --</option>
         
           <option value="Ring">Ring </option>
		   <option value="Link"> Link </option>  
		   
       </td>   </select>		</tr>   
<!--==============================================================================================-->
        <tr> <td width=10%> <label for ="title"> حالة الخدمة     :</label> </td>
   <!--<td width=10%> <input type="text" id="stats" name=" stats" size="55"> </td> </tr>-->
   <td width=10%><select name="stats" class="stats">
<option selected="selected">--  اختار حالة الخدمه  --</option> 
         
           <option value="سقوط الخدمة">سقوط الخدمة </option>
		   <option value="الخدمة منقولة">الخدمة منقولة </option>
		   <option value="اتأثير علي الخدمة">لاتأثير علي الخدمة </option>
		   
       </td>   </select>		</tr>   
   
     <tr> <td width=10%> <label for ="title">   وحدة الأعمال المتأثرة :</label> </td>
<td width=10%> 
 <input type="checkbox" name="time[]" value="محمول">محمول 
<input type="checkbox" name="time[]" value="ISP">ISP
<input type="checkbox" name="time[]" value="دولي">دولي
<input type="checkbox" name="time[]" value="شركات">شركات
<input type="checkbox" name="time[]" value="TE">TE
   </td> </tr>
   
      <tr> <td width=10%> <label for ="title"> الخدمة المتأثرة   :</label> </td>
   <td width=10%> 
   <input type="text" id="affected1" name=" affected1"  size="2" value="0E1">
   <input type="text" id="affected2" name=" affected2"  size="2" value="0E3">
   <input type="text" id="affected3" name=" affected3"  size="3" value="0STM-1">
   <input type="text" id="affected4" name=" affected4"  size="3" value="0STM-4">
   <input type="text" id="affected5" name=" affected5"  size="4" value="0STM-16">
   <input type="text" id="affected6" name=" affected6"  size="4" value="0STM-64">

   </td>


   </tr>
   
     <tr> <td width=10%> <label for ="title">  سبب العطل     :</label> </td>
      <td width=10%><select name="cause" class="cause">
<option selected="selected">--  اختار سبب العطل  --</option> 
       <? 
	    while($row = mysql_fetch_array( $sql_causes)){           
            $causes=$row['causes'];
            echo '<option value="'.$causes.'">'.$causes.'</option>';
        } ?></td>   </select>		</tr>
   
     <tr> <td width=10%> <label for ="title">  تاريخ بدايةالعطل     :</label> </td>
	    <td><div class="input-append date form_datetime">
<input size="55" type="text" value="" id="strt_flt" name="strt_flt"  readonly>
<span class="add-on"><i class="icon-th"></i></span>

</div></td></tr>
	 <tr> <td width=10%> <label for ="title">  تاريخ نهاية العطل      :</label> </td>

   
   <TD><div class="input-append date form_datetime">
<input size="55" type="text" value="" id="end_flt" name=" end_flt"  readonly>
<span class="add-on"><i class="icon-th"></i></span>

</div></TD></TR>
<!-- differnve between stat date and end date
select strt_flt ,end_flt ,TIMEDIFF(end_flt,strt_flt) farq from tbl_fra where id=16401-->
      
   <TD width=10%><label for ="title">  الإدارة المسئوله  :</label></TD>
   <td width=10%><select name="admin" class="admin">
<option selected="selected">--اختار الاداره العامه --</option> 
       <? 
	    while($row = mysql_fetch_array($sql_admins))
        {           
            $admin=$row['admin'];
            echo '<option value="'.$admin.'">'.$admin.'</option>';
   } ?></td>   </select>		</tr>   

   <tr> <td width=10%> <label for ="title">  مهندس الورديه        :</label> </td>
<td width=10%> م / <input type='text' name="eng" class="eng" list='2kx'>
    <datalist id='2kx'>
       <? while($row = mysql_fetch_array($sql_eng)){ $eng_name=$row[0];
         ?><option value="<?=$eng_name;?>"><?=$eng_name;?></option><?}?>
	</datalist> </td></tr>
   
     <tr> <td width=10%> <label for ="title">  ملاحظات         :</label> </td>
   <td width=10%> <input type="text" id="comnt" name=" comnt" size="55" > </td> </tr>
   
  
   	<tr> <td width=10%> <label for ="title"> ادخل البيانات     :</label> </td>
       <td width=10px>
	   
	       <input type="button" id="click2" value="...insert"   class='v11' > 
	   </td> </tr> 
			
		</table>
		
		
		
		
		
<div class='abx'></div>
	</form> 
		<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
     <script type="text/javascript">
     //alert('zanaty0');
 $(function(){$("form#myform").submit(function(){
			//alert('zanaty1');
		     $.ajax({type:"POST",data: $(this).serialize(),
                url: "../../works/ajax/ajaxinsert.php",
                success: function(msg){$(".abx").html(msg);}});
				return false;});
				
			 	
	});
	$('.v11').click(function(){
	//alert("mahmoud");
		 var a = confirm('هل ترغب فى ارسال البيانات');
		 if(a=='1'){
		$("form#myform").submit();
			
		}
 	});
 
  </script>	
<script type="text/javascript" src="../xtras/bootstrap/js/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="../xtras/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../xtras/bootstrap/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
 
<script type="text/javascript">
$(".form_datetime").datetimepicker({
format: "yyyy-mm-dd hh:ii"
});
</script>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<!--<script type="text/javascript" src="../../xtras/bootstrap/js/jquery-1.4.2.min.js"></script></script>-->
<script type="text/javascript">
$(document).ready(function(){
$(".country").change(function(){
var id=$(this).val();
var dataString = 'gov='+ id;
$.ajax
({
type: "POST",
url: "ajax_city.php",
data: dataString,
cache: false,
success: function(html)
{$(".city").html(html);} 
});

});

$(".country2").change(function(){
var id=$(this).val();
var dataString = 'gov='+ id;
$.ajax
({
type: "POST",
url: "ajax_city.php",
data: dataString,
cache: false,
success: function(html)
{$(".city2").html(html);} 
});

});


});
</script>