 <div class='contx'>
		<div class='pagex'>
		<meta charset="utf-8">
				<style> 

   .myTable tr:nth-child(2n-1) {
             background-color: #aaa ;
             }
   .myTable tr:nth-child(2n) {
             background-color: #ccc ;
             } 
#mmx {text-align:center;} 
body
{
font-family:arial;
}
.preview
{
width:400px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
}     
</style>
    <link href="../../xtras/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="../../xtras/bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
	
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>



<?php 
//127.0.0.1/law/works/ajax/inser_cbl.php


 include('../../xtras/session.php');
include('../../xtras/config.php');
echo '</br>';

   ?>
   
   <center>
   <form  id="myform"  dir='rtl'> 
   
   <table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'>
     <?
   $sql_gov=mysql_query("select id,gov_name from tbl_gov");
   $sql_admins=mysql_query("select admin,admin from tbl_admins ");   
   $sql_eng=mysql_query("select eng_name,eng_name from tbl_engs  ");
   
   
   ?>
   
      
  <!-- <tr> <td width='150px'> <label for ="title">  بين محافظة    :</label> </td> 

<td width=10%><input type='text' name="country" class="country" list='lkx'>
    <datalist id='lkx'>
       <? while($row = mysql_fetch_array($sql_gov)){
	   $id=$row[0];
	   $gov_name=$row[1];
         ?><option value="<?=$gov_name;?>"><?=$gov_name;?></option><?}?>
	</datalist> 
      
   <label> ومدينة</label> <select name="city" class="city">
<option selected="selected">--Select City--</option>
</select></td></tr>
-->

   
   
   <tr> <td width='150px'> <label for ="title">   تصنيف القضايا   :</label> </td>
   <td width=10%><select name="country" class="country">
<option selected="selected">-اختار تصنيف القضايا-</option>         
           <option value="tbl_problem_family">أسره   </option>
		   <option value="tbl_problem_msdmnr"> جنح   </option>
           <option value="tbl_problem_civil"> مدني  </option>   
		          </td>   </select>		</tr> 
				  
				    <!-- <tr> <td width='150px'><label> ومدينة</label> </td><td><select name="city" class="city">
                     <option selected="selected">--Select City--</option>
                    </select></td></tr>-->
					
					  <!-- <label> ومدينة</label> <select name="city5" class="city5">
<option selected="selected">--Select City--</option>
</select></td></tr> -->
	   

    <tr> <td width='150px'> <label for ="title">  اسم الموكل   :</label> </td>   
     <td width=30%> <input type="text" id="Flt_cause" name=" Flt_cause" size="55">    </TD></TR>
	   
     <tr> <td width='150px'> <label for ="title">  اسم الخصم   :</label> </td>   
     <td width=30%> <input type="text" id="down" name=" down" size="55" value=' سنترال  ' >    </TD></TR>
	 
	 <tr> <td width='150px'> <label for ="title">  رقم القضيه   :</label> </td>   
     <td width=30%> <input type="text" id="clnt" name=" clnt" size="25" value='  المصريه للاتصالات' >     </TD></TR>
	 
      
   <td width='150px'><label for ="title">  نوع القضيه   :</label></TD>
   <td width=10%><select name="city5" class="city5">
<option selected="selected">--اختار الاداره العامه --</option> 
   		</tr>   

   <tr> <td width='150px'> <label for ="title">  تاريخ الجلسه اول درجه    :</label> </td>   
     <td width=30%> <input type="text" id="Flt_cause" name=" Flt_cause" size="55">    </TD></TR>
	 
	 
	 <tr> <td width='150px'> <label for ="title"> رقم الاستئناف     :</label> </td>   
     <td width=30%> <input type="text" id="Flt_cause" name=" Flt_cause" size="55">    </TD></TR>
	 
	 <tr> <td width='150px'> <label for ="title"> تاريخ جلسة الاستئناف      :</label> </td>   
     <td width=30%> <input type="text" id="Flt_cause" name=" Flt_cause" size="55">    </TD></TR>
	 
   
     <tr> <td width='150px'> <label for ="title">  ملاحظات         :</label> </td>
   <td width=30%> <input type="text" id="cmnts" name="cmnts" size="55">    </TD></TR>
   
  
   	<tr> <td width='150px'> <label for ="title"> ادخل البيانات     :</label> </td>
       <td width=10px>
	   
	       <input type="button" id="click2" value="...insert"   class='v11' > 
	   </td> </tr> 
			
		</table>
		
		
		
		
		
<div class='abx'></div>
	</form> 
		<!--<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>-->
		<script src="../../xtras/bootstrap/js/jquery-1.11.0.min.js"></script>
     <script type="text/javascript">
     //alert('zanaty0');
 $(function(){$("form#myform").submit(function(){
			//alert('zanaty1');
		     $.ajax({type:"POST",data: $(this).serialize(),
                url: "../../works/ajax/ajaxinst_cbl.php",
                success: function(msg){$(".abx").html(msg);}});
				return false;});
				
			 	
	});
	$('.v11').click(function(){
	//alert("mahmoud");
		 var a = confirm('هل ترغب فى ارسال البيانات');
		 if(a=='1'){
		$("form#myform").submit();
			
		}
 	});
 
  </script>	
<script type="text/javascript" src="../../xtras/bootstrap/js/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../../xtras/bootstrap/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
 
<script type="text/javascript">
$(".form_datetime").datetimepicker({
format: "yyyy-mm-dd hh:ii"
});
</script>

<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>-->
<script type="text/javascript" src="../../xtras/bootstrap/js/jquery.min.js"></script></script>
<script type="text/javascript">
$(document).ready(function(){
//alert("zanaty");
$(".country").change(function(){
var id=$(this).val();
var dataString = 'gov='+ id;
//alert(dataString);
$.ajax
({
type: "POST",
url: "ajax_city.php",
data: dataString,
cache: false,
success: function(html)
{$(".city5").html(html);} 
});

});

});
</script>