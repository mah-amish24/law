<?php
include('../../xtras/config.php');
   // Get the parameters from URL
   $params['keyword'] = $_GET['keyword'];
   $params['city'] = $_GET['city'];
   $params['state'] = $_GET['state'];

   // Start building query
   $sql = "SELECT * FROM users WHERE ";       

   // Loop through GET params and create WHERE clause
   foreach($params as $key=>$value)
   {
      // Only add to query if parameter not empty
      if( !empty(trim($value)) )
      {
         // Add to an array to be joined later using "AND"
         switch ($key) {
            case 'keyword':
               $whereCond[] = "ClinicName LIKE '%$value%'";
               break;
            case 'city':
               $whereCond[] = "LocationCity LIKE '%$value%'";
               break;
            case 'state':
               $whereCond[] = "LocationRegion LIKE '%$value%'";
               break;
         }
      }
   }

   // With where conditions, use a counter so 
   // we dont add "AND" to last one
   $iCount = 0;
   $iTotal = count($whereCond);  

   // Combine WHERE clause and add to query
   foreach($whereCond as $cond)
   {
      if($iCount != $iTotal)
      {
         $sql .= $cond . " AND ";
      } else {
         $sql .= $cond;
      }

      // Increment counter
      $iCount++;
   }

   // Run query
   $query = mysql_query($sql) or die(mysql_error());
   