<html>
<head>
<script>
function showHint(str,type)
{
    var str2 = '';
    if (type == 1)
    {
        if (str.length==0 && document.getElementById('users').value == '')
        {
            document.getElementById("txtHint").innerHTML="";
            return;         
        } else {
            str2 = document.getElementById('users').value;
        }
    } else {
        if (str.length==0 && document.getElementById('text').value == '')
        {
            document.getElementById("txtHint").innerHTML="";
            return;         
        } else {
            str2 = document.getElementById('text').value;
        }
    }

if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","gethint.php?q="+str+'&str2 = '+str2,true);
xmlhttp.send();
}
</script>
</head>
<body>

<p><b>Start typing a name in the input field below:</b></p>
<form>
First name: <input type="text" id = "text" onkeyup="showHint(this.value,'1');">
<select name="users" id = 'users' onchange="showHint(this.value','2');">
<option value="">Select a person:</option>
<option value="1">Peter Griffin</option>
<option value="2">Lois Griffin</option>
<option value="3">Glenn Quagmire</option>
<option value="4">Joseph Swanson</option>
</select>
</form>
<p>Suggestions: <span id="txtHint"></span></p>

</body>
</html>



<!--<script type="text/javascript">
function showHint(keyword, city, state) {
    var xmlhttp;
    if(keyword.length == 0 & city.length == 0 & state.length == 0) {
        document.getElementById("txtHint").innerHTML = "";
    }
    if(window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    } else { // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function () {
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("txtHint").innerHTML = xmlhttp.responseText;
        }
    }
    xmlhttp.open("GET", "gethint.php?keyword=" + keyword + "&city=" + city + "&state=" + state, true);
    xmlhttp.send();
}
</script>
<!--127.0.0.1/law/works/ajax/test.php-->
<!--<form action="" id="livesearch" id="livesearch"> 
Clinic Name: <input type="text" id="clinicsearch" name="clinicsearch" autocomplete="off" onkeyup="keyword=this.value; showHint(keyword, city, state);" />
City: <input type="text" id="citysearch" name="citysearch" autocomplete="off" onkeyup="city=this.value; showHint(keyword, city, state);" />
State: <input type="text" id="statesearch" name="statesearch" autocomplete="off" onkeyup="state=this.value; showHint(keyword, city, state);" />
</form>-->