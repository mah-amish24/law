
<!--127.0.0.1/law/works/ajax/example-jquery_calendar.php-->
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" />
<script type="text/javascript" src="jquery.1.4.2.js"></script>
<script type="text/javascript" src="jsDatePick.jquery.min.1.3.js"></script>
<script type="text/javascript">
	window.onload = function(){
		new JsDatePick({
			useMode:2,
			target:"inputField",
			dateFormat:"%d-%m-%Y"			
		});
	};
</script>

	  
    <input type="text" size="12" id="inputField" />
    

<?php
echo "zanaty";
$pinibl =@ show_source("http://www.montadaphp.net");
echo $pinibl;

?>