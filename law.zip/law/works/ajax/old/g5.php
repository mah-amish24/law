<?
	$k = $_GET['k'];
	include('../../xtras/config.php');
	$sql = mysql_query("select gov_name from tbl_gov where id='$k'");
	$r = mysql_fetch_array($sql);
	$name = $r[0];
?>
<script>
	$().ready(function(){
		$('.dmd').val('<?=$name;?>');
		$('.custo').val('<?=$k;?>');
		$.ajax({url:'xtras/show2.php?p=<?=$k;?>&cat='+$('.cat').val(),success: function(data){$('.paper').html(data);}});
	
	});
</script>