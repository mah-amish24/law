<head> 
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<script>
var tableToExcel = (function() {
  var uri = 'data:application/vnd.ms-excel;base64,'
    , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table border="2">{table}</table></body></html>'
    , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
    , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
  return function(table, name) {
    if (!table.nodeType) table = document.getElementById(table)
    var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
    window.location.href = uri + base64(format(template, ctx))
  }
})()



</script>
<script>
 $(function(){$("form#myform").submit(function(){
			//alert('zanaty1');
		     $.ajax({type:"POST",data: $(this).serialize(),
                url: "ajax_city.php",
                success: function(msg){$(".aby").html(msg);}});
				return false;});
				
			 	
	});
 $('.v11').click(function(){
	//alert("mahmoud");
		// var a = confirm('هل ترغب فى ارسال البيانات');
		// if(a=='1'){
		$("form#myform").submit();
			
	//	}
 	});
 
  </script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
<link rel="stylesheet" href="/resources/demos/style.css">
<script>
$(function() {
$( "#datepicker" ).datepicker({
showOn: "button",
buttonImage: "../works/ajax/calendar.gif",
buttonImageOnly: true,
buttonText: "Select date"
});
});
</script>
</head>
<input type="button" onclick="tableToExcel('myTable', 'W3C Example Table')" value="طباعة في اكسل">
<!--<input type='text' name ='hid'  id='datepicker' class='mgx'>-->
<?php
//localhost/law/works/ajax/lawer_daily_ajax.php
include('../../xtras/config.php');
//include('../../xtras/session.php')
 //$when=$_POST['when'];
//echo "</BR>";
 $inputdate=$_POST['inputField'];
//if($_POST['inputField']){
 $client=$_POST['inputField'];
 //if (!empty($client))
 
 
 if(empty($_POST['when'])){
if($inputdate!='--اختار التاريخ--'){
$stmnt=" select a.*,b.client_name ,b.prblm_type from tbl_first_dgree a ,tbl_problems b  where a.prblm_no=b.prblm_no and session_date='$client' order by session_date ";
}  }
if(!empty($_POST['when'])){
if(($_POST['when'])=='now'&!empty($inputdate)){
//if($when=='now'&$inputdate=='--اختار التاريخ--'){
$stmnt="select a.*,b.client_name ,b.prblm_type from tbl_first_dgree a ,tbl_problems b  where a.prblm_no=b.prblm_no and YEAR(session_date) = YEAR(NOW())  AND MONTH(session_date) = MONTH(NOW()) AND DAY(session_date) = DAY(NOW()) order by session_date";
}
//if($when=='today'&$inputdate=='--اختار التاريخ--'){
if(($_POST['when'])=='today'&!empty($inputdate)){
$stmnt="select a.*,b.client_name ,b.prblm_type from tbl_first_dgree a ,tbl_problems b  where a.prblm_no=b.prblm_no and YEAR(session_date) = YEAR(NOW())  AND MONTH(session_date) = MONTH(NOW()) AND DAY(session_date) = DAY(NOW())+1 order by session_date";
}
if(($_POST['when'])=='week'&!empty($inputdate)){
//if($when=='week'&$inputdate=='--اختار التاريخ--'){
$stmnt="select a.*,b.client_name ,b.prblm_type from tbl_first_dgree a ,tbl_problems b  where a.prblm_no=b.prblm_no and session_date between (adddate(curdate(), INTERVAL 0-DAYOFWEEK(curdate()) DAY) )and  (adddate(curdate(), INTERVAL 6-DAYOFWEEK(curdate()) DAY)) order by session_date" ;

}
if(($_POST['when'])=='month'&!empty($inputdate)){

$stmnt="select a.*,b.client_name ,b.prblm_type from tbl_first_dgree a ,tbl_problems b  where a.prblm_no=b.prblm_no and YEAR(session_date) = YEAR(NOW()) AND MONTH(session_date)=MONTH(NOW()) order by session_date";
}
}
 $sql=mysql_query($stmnt);
 
 
 echo" <form  id='myform' method='post' >
 <table width='600px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='myTable' class='myTable'>
<tr><td width='20px'> م</td> 
<td width='250px'>    اسم الموكل  </td> 
<td width='200px'>    نوع القضيه </td>
<td width='50px'>    رقم القضيه </td>
<td width='50px'>الجلسه القادمه </td>
<td width='250px'>تقرير الجلسـه السابقه</td>
<td width='150px'>ملاحـظات</td>

</tr>";?>
<!--<td width='150px'>قرار الجلسه</td>
<td width='150px'>الجلسه القادمه</td>
<td width='150px'>ملاحـظات</td>
<td width='150px'>ادخال</td> -->
<?$i=0;
while($row=mysql_fetch_array($sql))
{
$i++;
$prblm_no=$row['prblm_no'];
$session_date=$row['session_date'];
$prev_action=$row['prev_action'];
$cmnts=$row['cmnts'];
?>
       <tr id='jm'class='x<?=$i;?>' onclick="$('.mgx').val('<?=$prblm_no;?>')"> <td> <?=$i;?>  </td>
              <?   echo"  <td>  $row[client_name]     </td>
				  <td>  $row[prblm_type]       </td>
				  <td> <a href='//localhost/law/works/ajax/livesearch.php?prblm_no=$prblm_no'>$prblm_no</a>         </td>
				  <td>  $row[session_date]   </td>
				  <td>  $row[prev_action]    </td>
				  <td>  $row[cmnts]          </td> 				  
                 </tr>				   ";?>
				  <!-- <td><input type="text" width="68" onchange = "$.ajax({url:'ajxinst_prblm.php?cmnts=<?=$tbl;?>&insrt='+$(this).val(),success: function(data){$('.aby').html(data);}});"  ></td>-->
				 <!-- <td width=10%><select name='prblm_cls' class='prblm_cls'>
         <option selected='selected'>-اختار قرار الجلسه  -</option>
           <option value='tbl_problem_family'>تأجيل للشهود </option>
		   <option value='tbl_problem_msdmnr'> تأجيل للاطلاع    </option>
           <option value='tbl_problem_civil'>تأجيل للحكم  </option>  </td>   </select>
                   <td><input  type='text' id='datepicker_' size='15' value='    -    -  2015  '/>  </td>
                   <td><input  type='text' id='cmnts_nxt' size='15' value=''/>  </td>
                   <td> <input type='button' id='click2' value='...ادخال'   class='v11' > <td> -->
				  <?  


}
echo "</table> </form>";
//}


?>
<div class='aby'></div>