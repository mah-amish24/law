<style type="text/css">
.searchResults { width:70%; border-collapse:collapse;  }
.searchResults td { padding:8px; border:#999 1px solid; }
 
.searchResults tr:nth-child(even) { /*(even) or (2n 0)*/
	background: #A4D1FF;
}
.searchResults tr:nth-child(odd) { /*(odd) or (2n 1)*/
	background: #EAF4FF;
}
</style>
<!--<a href="javascript: //history.go(-1)">Go Back</a> 
</br><a href="##" onClick="history.back(); return false;">Go back 2</a> 
<a href="#" onclick="javacript:history.go(-1);">text</a>-->
<div style="direction:rtl;"><a href ="javascript:history.back()"> الصفحه السابقه </a></div>
  <?php
//header("location:javascript://history.go(-1)");
header('Content-type: text/html; charset=utf-8');
include('../../xtras/config.php');

$str1="select * from tbl_problems b where ";

$str = "SELECT a.id,a.prblm_cls,a.client_name,a.client_tel,a.client_sefa,a.Opponent_name,a.Opponent_sefa,a.Opponent_tel,a.prblm_no,a.appeal_no,a.twkl_no,a.cycle_no,a.mhkma,a.prblm_type,a.cmnts,a.crt_date,b.id, b.prblm_no,b.session_date,b.`prev_action`,b.cmnts notes  FROM tbl_problems a , tbl_first_dgree b  where a.prblm_no=b.prblm_no and  ";
			
            if (!empty($_GET['prblm_no'])) { $prblm_no = $_GET['prblm_no']; $cond=" b.prblm_no LIKE '%$prblm_no%' ";$str1=$str1.$cond; $str=$str.$cond; }
			if (!empty($_POST['client'])) { $client=$_POST['client']; $prblm_type=$_POST['prblm_type'];
			$cond=" client_name LIKE '%$client%'  and prblm_type LIKE '%$prblm_type%' ";$str1=$str1.$cond; $str=$str.$cond; }
			
			
                $i = 0;
				$result = mysql_query($str1)or die(mysql_error());  
				echo"<form  id='myform'  dir='ltr'> <center>";
				$row = mysql_fetch_assoc($result);
				echo"<input name=\"prblm_no\" type=\"hidden\" id=\"prblm_no\" value=\"" .$row['prblm_no']. "\">"; ?>
				<table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='searchResults' class='searchResults'>
                  <tr><td width='150px'>    رقم القضيه </td><td width='150px'> <?= $row['prblm_no']?>   </td>
				  <td width='100px'>    رقم الاستئناف 
				  </td><td width='100px'>  <?=$row['appeal_no']?>   </td>				  
				  <td width='100px'>    رقم التوكيل </td><td>  <?=$row['twkl_no']?>   </td></tr>		  
				  
				  
				  <tr><td>    الموكل </td><td>  <?=$row['client_name'] ?>  </td>
				  <td>   صفة الموكل   </td><td>  <?=$row['client_sefa']?>   </td>
				  <td>      تليفون الموكل   </td><td>  <?=$row['client_tel']?>   </td></tr>
				  
				  
				  <tr><td>    الخصم  </td><td>  <?=$row['Opponent_name']?>   </td>				  
				  <td>    صفة الخصم  </td><td>  <?=$row['Opponent_sefa'] ?>  </td>
				  <td>    تليفون الخصم  </td><td>  <?=$row['Opponent_tel']?>   </td></tr>
				  
				  <tr><td>    نوع القضيه </td><td>  <?=$row['prblm_type'] ?>  </td>
				  <td>    رقم الدائره  </td><td>  <?=$row['cycle_no']?>   </td>
				  <td>    المحكمه  </td><td>  <?=$row['mhkma'] ?>  </td> </tr>
				 <tr> <td>    تاريخ دخول القضيه المكتب   </td><td>  <?=$row['crt_date']?>   </td>
				  <td >    ملاحظات  </td><td colspan='3'>  <?=$row['cmnts']?>   </td> 	  
				  </tr> 
				  </table>				  
				<? 
				 echo"</br>";
                $query = mysql_query($str);
                while ($row = mysql_fetch_assoc($query))
                {
                    $i++;
                  			  
				  echo"<table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='searchResults' class='searchResults'> 
				  <tr><td>    تقرير الجلسـه السابقه ($i)</td><td>  $row[prev_action]   </td></tr>
				  <tr><td width='150px'>   الجلسه الــــــــــــقادمه ($i) </td><td>  $row[session_date]   </td></tr>
                  <tr><td>    ملاحـــــــــــــــــــظات  ($i) </td><td>  $row[notes]   </td></tr>
				  
				  </table>";	
                 echo "</br>";				  
					}
				
            
			
			echo"</br> ";
			//<tr><td>    تقرير الجلسـه السابقه </td><td>  <input id='action' type='text' name='action'size='55'  />   </td></tr>
			echo "
			<table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='searchResults' class='searchResults'> 
			
			    <tr> <td>    تقرير الجلسـه السابقه </td>  <td width=10%><select name='action' class='action'>
         <option selected='selected'>-اختار قرار الجلسه  -</option>
           <option value='تأجيل للشهود'>تأجيل للشهود </option>
		   <option value='تأجيل للاطلاع'> تأجيل للاطلاع    </option>
           <option value='تأجيل للحكم'>تأجيل للحكم  </option>    </select> </td> </tr>
			
			<tr><td width='150px'>     الجلسه الــــــــــــقادمه </td><td>  <input  type='text' name='prblm_date' id='prblm_date' size='55'  />  </td></tr>
				  
				  <tr><td>     ملاحـــــــــــــــــــظات </td><td>  <input id='cmnts' type='text' name='cmnts'size='55'  />   </td></tr>
				  <tr> <td> ادخل البيانات</td>  <td>  <input type='button' id='click2' value='...ادخال'   class='v11' > 
	              <input type='reset' id='click3' value='.....تفريغ'   > </td> </tr> 
			</table> <div class='abx'></div>";  ?>
			
<form>
				  
        
		
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" />
<script type="text/javascript" src="jquery.1.4.2.js"></script>
<script type="text/javascript" src="jsDatePick.jquery.min.1.3.js"></script>
<script type="text/javascript">	window.onload = function(){	new JsDatePick({useMode:2,target:"prblm_date",dateFormat:"%Y-%m-%d"	});	};	</script>
	
	<script type="text/javascript">
     
 $(function(){$("form#myform").submit(function(){
			//alert('zanaty1');
		     $.ajax({type:"POST",data: $(this).serialize(),
               	url: "ajxinst_prblm.php",
                success: function(msg){$(".abx").html(msg);}});
				return false;});
				
			 	
	});
	$('.v11').click(function(){
	//alert("mahmoud");
		 var a = confirm('هل ترغب فى ارسال البيانات');
		 if(a=='1'){
		$("form#myform").submit();
			
		}
 	});
 
  </script>
	
</head>
<body>
	  
    