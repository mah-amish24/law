<?php
system('cmd.exe /c D:\MySQLBackups\mysqlbackup.bat');
?>