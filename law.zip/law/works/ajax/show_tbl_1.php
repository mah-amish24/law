<meta charset="utf-8">

<?php
include('../../xtras/session.php');
 include('../../xtras/config.php');
//$tbl=$login_session;
//localhost/law/works/ajax/show_tbl.php
   ?>
<head>
<script language="javascript">
function printdiv(printpage)
{
var headstr = "<html><head><title></title></head><body>";
var footstr = "</body>";
var newstr = document.all.item(printpage).innerHTML;
var oldstr = document.body.innerHTML;
document.body.innerHTML = headstr+newstr+footstr;
window.print();
document.body.innerHTML = oldstr;
return false;
}
</script>

<script type="text/javascript">
var tableToExcel = (function() {
  var uri = 'data:application/vnd.ms-excel;base64,'
    , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
    , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
    , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
  return function(table, name) {
    if (!table.nodeType) table = document.getElementById(table)
    var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
    window.location.href = uri + base64(format(template, ctx))
  }
})()
</script>

   <style> 
    #mmx {text-align:center;}   
	#mmx input {width:100%;background:transparent;border:0px;}   
    .myTable tr:nth-child(even) {background: #EAF4FF;}
   .myTable tr:nth-child(odd) {background: #A4D1FF; }
   body {    font-size: 100%; }
</style>

</head>
<body>
<!--<input name="b_print" type="button" class="ipt"   onClick="printdiv('div_print');" value=" Print ">-->
   
   
   <div id="div_print">
  <table width='100%' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'> 
   <tr>
  <td width='2%'> حزف   </td>
  <td width='2%'> م   </td> 
  <td width=7%> رقم القضيه  </td>
  <td width='15%'> اسم الموكل   </td>
  <td width=10%>نوع القضيه  </td>  
  <td width=5%> صفتة  </td>
  <td width=5%> تليفون  </td>
  
  <td width='10%'> اسم الخصم   </td> 
  <td width=5%> صفتة  </td>
  <td width=5%> تليفون  </td>
  
  
  <td width=7%> رقم الاسئناف  </td>
  <td width=7%> رقم التوكيل  </td>
  <td width=10%> رقم الدائره   </td>
  <td width=5%> محكمه  </td>
  
  <td width=15%>ملاحظات  </td> 
  
   </tr> 
   <?
   $get_data="select *  from tbl_problems  order by client_name ";
   $tbl ="tbl_problems";
   $sql = mysql_query($get_data );
   $i=1;while($row = mysql_fetch_array($sql))  {
   $id = $row[0];
      		?>
      <tr id='jm'class='x<?=$i;?>' onclick="$('.mgx').val('<?=$id;?>')" > 

	   
      			<td><img src="<?php echo 'img/trash.png' ?>" width="30" height="20" onclick = "$('.x<?=$i;?>').hide('slow'),$.ajax({url:'../../works/ajax/ajaxdelete.php?tbl=<?=$tbl;?>&id=<?=$id;?>',success: function(data){$('.abx').html(data);}});" /></td>
				 <td >  <?=$i;?>   </td>
               <!-- <td><input type="text" name="hid" id="hid"  value='<?=$row[0];?>' > </td>	-->	
                <td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=prblm_no&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[8];?>' ></td>		   
				
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=client_name&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[2];?>' ></td>
				
				
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=prblm_type&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[13];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=client_sefa&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[4];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=client_tel&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[5];?>' ></td>
				
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=Opponent_name&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[3];?>' ></td>				
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=Opponent_sefa&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[6];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=Opponent_tel&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[7];?>' ></td>
				
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=appeal_no&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[9];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=twkl_no&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[10];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=cycle_no&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[11];?>' ></td>
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=mhkma&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[12];?>' ></td>
				
				<td><input type="text" onchange = "$.ajax({url:'../../works/ajax/ajaxupdate.php?tbl=<?=$tbl;?>&id=<?=$id;?>&t=cmnts&v='+$(this).val(),success: function(data){$('.abx').html(data);}});" value='<?=$row[14];?>' ></td>
				
					
				</td>
				
	   </tr> 
   <? $i++;}
   
  	?>
	</div> 
   <div class='abx'></div>     
<script type="text/javascript" src="jquery.1.4.2.js"></script>

<body>
	

   
   
   