<meta charset="utf-8">
<?php
 include('../../xtras/session.php');
 include('../../xtras/config.php');

 ECHO $prblm_date= $_POST['prblm_date'];
 ECHO $action = $_POST['action'];
//$client_name = $_POST['client_name'];
//$Opponent_name = $_POST['Opponent_name'];
 ECHO $prblm_no = $_POST['prblm_no'];
 ECHO $cmnts = $_POST['cmnts'];



echo'</br>';
$sql_statemanet ="INSERT INTO tbl_first_dgree (prblm_no,session_date,prev_action,cmnts)
VALUES('$prblm_no','$prblm_date','$action','$cmnts') ";
				
echo  "sql_statemanet >>".$sql_statemanet ;							  
								        mysql_query( $sql_statemanet);
	
 
   echo "<script> 
   alert(\" تمت عملية ادخال البيانات  بنجاح \");
   
      
   </script>";
		
?>
