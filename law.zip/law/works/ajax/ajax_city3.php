<?php
include('../../xtras/config.php');

if($_POST['client']){
$client=$_POST['client'];

$stmnt=" select  id,prblm_type  from tbl_problems where client_name='$client' ";
//echo "<script type=\"text/javascript\"> alert(\" zanaty.$stmnt \");  </script>";
 $sql=mysql_query($stmnt);
echo '<option selected="selected">-اختار نوع القضيه-</option>';
while($row=mysql_fetch_array($sql))
{
$id=$row['id'];
$data=$row['prblm_type'];
echo '<option value="'.$data.'">'.$data.'</option>';
}				
}

?>