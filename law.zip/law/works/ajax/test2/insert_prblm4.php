 <div class='contx'>
		<div class='pagex'>
		<meta charset="utf-8">
				<style> 

   .myTable tr:nth-child(2n-1) {
             background-color: #aaa ;
             }
   .myTable tr:nth-child(2n) {
             background-color: #ccc ;
             } 
#mmx {text-align:center;} 
body
{
font-family:arial;
}
.preview
{
width:400px;
border:solid 1px #dedede;
padding:10px;
}
#preview
{
color:#cc0000;
font-size:12px
}     
</style>
<?php 
//127.0.0.1/law/works/ajax/test2/insert_prblm4.php


 include('../../../xtras/session.php');
include('../../../xtras/config.php');
echo '</br>';

   ?>
   
   <center>
   <form  id="myform"  dir='rtl'> 
   
   <table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'>
     <?   $sql_gov=mysql_query("select id,gov_name from tbl_gov");
         $sql=mysql_query("select id,client_name from tbl_problems");
	 ?>
   
   <tr> <td width='150px'> <label for ="title">  اسم الموكل   :</label> </td> 

<td width=10%><input type='text' name="client" class="client" list='lkx'>
    <datalist id='lkx'>
       <? while($row = mysql_fetch_array($sql)){
	   $id=$row[0];
	   $client_name=$row[1];
         ?><option value="<?=$client_name;?>"><?=$client_name;?></option><?}?>
	</datalist> 
      </td></tr>
	  				  
<td width='150px'><label for ="title">  نوع القضيه   :</label></TD>
   <td width=10%> <select name="prblm_type" class="prblm_type"> 
<option selected="selected">- اختار نوع القضيه-</option>

  </td> </tr> 
   
    <tr> <td width='150px'> <label for ="title">  اسم الموكل   :</label> </td>   
     <td width=30%> <input type="text" id="client_name" name=" client_name" size="55">    </TD></TR>
	   
     <tr> <td width='150px'> <label for ="title">  اسم الخصم   :</label> </td>   
     <td width=30%> <input type="text" id="Opponent_name" name=" Opponent_name" size="55" >    </TD></TR>
	 
	 <tr> <td width='150px'> <label for ="title">  رقم القضيه   :</label> </td>   
     <td width=30%> <input type="text" id="prblm_no" name=" prblm_no" size="25"  >     </TD></TR>
	 
	 <tr> <td width='150px'> <label for ="title">  ملاحظات   :</label> </td>   
     <td width=30%> <input type="text" id="cmnts" name=" cmnts" size="25"  >     </TD></TR>
	 
	 
   	<tr> <td width='150px'> <label for ="title"> ادخل البيانات     :</label> </td>
       <td width=10px>
	   
	       <input type="button" id="click2" value="...insert"   class='v11' > 
	   </td> </tr> 
			
		</table>
		
<div class='abx'></div>
	</form> 
	
	

		<script src="../../../xtras/bootstrap/js/jquery-1.11.0.min.js"></script>
     <script type="text/javascript">
     //alert('zanaty0');
 $(function(){$("form#myform").submit(function(){
			//alert('zanaty1');
		     $.ajax({type:"POST",data: $(this).serialize(),
                url: "../../works/ajax/ajaxinst_cbl.php",
                success: function(msg){$(".abx").html(msg);}});
				return false;});
				
			 	
	});
	$('.v11').click(function(){
	//alert("mahmoud");
		 var a = confirm('هل ترغب فى ارسال البيانات');
		 if(a=='1'){
		$("form#myform").submit();
			
		}
 	});
 
  </script>	

<script type="text/javascript" src="../../../xtras/bootstrap/js/jquery.min.js"></script></script>
<script type="text/javascript">
$(document).ready(function(){
//alert("zanaty");
$(".client").change(function(){
var id=$(this).val();
var dataString = 'client='+ id;
alert(dataString);
$.ajax
({
type: "POST",
url: "ajax_city4.php",
data: dataString,
cache: false,
success: function(html)
{$(".prblm_type").html(html);} 
});

});

});
</script>