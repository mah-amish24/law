<?php
header('Content-type: text/html; charset=utf-8');
$server="localhost";
$user="root";
$pass="";
$database="law";
$table="news";

$word=$_GET['qsearch'];
echo $word = $_REQUEST["qsearch2"];
$connection=mysql_connect($server,$user,$pass);
if(!$connection)
{
 die("DB Connection error: ".mysql_error());
}
mysql_select_db($database,$connection);
mysql_query("SET NAMES utf8"); //IMPORTANT


            if (!empty($word))
            {
                $i = 0;
                $str = "SELECT * FROM $table WHERE newsContent LIKE '%$word%'";
				
				echo $str;
                $query = mysql_query($str);
                while ($row = mysql_fetch_assoc($query))
                {
                    $i++;
                  			  
				  echo"<table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='searchResults' class='searchResults'>
                  <tr><td>    الرقم </td><td>  $row[newsID]   </td></tr>
				  <tr><td>    الاسم </td><td>  $row[newsTitle]   </td></tr>
				  <tr><td>    القضيه </td><td>  $row[newsContent]   </td></tr>  </table>";
					                    
					}
				
            }
        



?>