<?php
//127.0.0.1/law/works/ajax/test2/livesearch.php
echo "mahmoud";
?>