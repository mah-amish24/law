<?php
header('Content-type: text/html; charset=utf-8');
$server="localhost";
$user="root";
$pass="";
$database="law";
$table="news";
$output = "";
$word=$_GET['qsearch'];
$connection=mysql_connect($server,$user,$pass);
if(!$connection)
{
 die("DB Connection error: ".mysql_error());
}
mysql_select_db($database,$connection);
mysql_query("SET NAMES utf8"); //IMPORTANT


            if (!empty($word))
            {
                $i = 0;
                $str = "SELECT * FROM $table WHERE newsContent LIKE '%$word%'";
				
				echo $str;
                $query = mysql_query($str);
                while ($row = mysql_fetch_assoc($query))
                {
                    $i++;
                  // echo "<br/>$i: ($row[newsID], $row[newsTitle]): $row[newsContent]";
				  
				  echo"<table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='searchResults' class='searchResults'>
                  <tr><td>    الرقم </td><td>  $row[newsID]   </td></tr>
				  <tr><td>    الاسم </td><td>  $row[newsTitle]   </td></tr>
				  <tr><td>    القضيه </td><td>  $row[newsContent]   </td></tr>



				  </table>";
					
					
					
					
					
					/* $newsID = $row["newsID"];
                    $displayName = $row["newsTitle"];
                    $newsContent = $row["newsContent"];
                    $output .= '<li onclick="sendToSearch(\''.$newsID.'\')">'.$newsID.'</li>';
                    $output .= '<li onclick="sendToSearch(\''.$displayName.'\')">'.$displayName.'</li>';
                    $output .= '<li onclick="sendToSearch(\''.$newsContent.'\')">'.$newsContent.'</li>';*/

                     
					}
				
            }
        echo $output;



//database connections
/*$hostname = "localhost";
$user = "root";
$pass = "";
$database = "law";
//http://127.0.0.1/law/works/ajax/test/livesearch.php
$connection = mysql_connect($hostname, $user, $pass) or die(mysql_error());
mysql_select_db($database, $connection) or die(mysql_error());
mysql_query("SET NAMES utf8");
echo $s = $_REQUEST["qsearch"];
echo'</br>';
echo $s2 = $_REQUEST["qsearch2"];
		
$output = "";
$s = str_replace(" ", "%", $s);
$query = "SELECT * FROM news WHERE newsContent LIKE '%" . $s . "%'";
echo  "sql_statemanet >>".$query ;
$squery = mysql_query($query);
if((mysql_num_rows($squery) != 0) && ($s != "")){
//while ($row = mysql_fetch_assoc($query))
while($sLookup = mysql_fetch_assoc($squery)){
$newsID = $sLookup["newsID"];
$displayName = $sLookup["newsTitle"];
$newsContent = $sLookup["newsContent"];
$output .= '<li onclick="sendToSearch(\''.$newsID.'\')">'.$newsID.'</li>';
$output .= '<li onclick="sendToSearch(\''.$displayName.'\')">'.$displayName.'</li>';
$output .= '<li onclick="sendToSearch(\''.$newsContent.'\')">'.$newsContent.'</li>';
}
}

echo $output;*/
?>