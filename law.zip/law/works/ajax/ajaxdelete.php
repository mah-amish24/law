<meta charset="utf-8">
<?
	 $id = $_GET['id'];
	 $tbl = $_GET['tbl'];
		
	include('../../xtras/config.php');
	mysql_query("delete  from ".$tbl." where id='$id' ");
		

	
?>
<script>	alert('تمت عملية الحذف بنجاح');</script>