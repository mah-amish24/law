<html xmlns="http://www.w3.org/1999/xhtml" lang="ar" xml:lang="ar">
     <meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<style type="text/css">
.myTable { width:70%; border-collapse:collapse;  }
.myTable td { padding:8px; border:#999 1px solid; }
 
.myTable tr:nth-child(even) {background: #A4D1FF;}
.myTable tr:nth-child(odd) {background: #EAF4FF;}	 
#mmx {text-align:center;} 
body{font-family:arial;}
.preview{width:400px;border:solid 1px #dedede;padding:10px;}
#preview{color:#cc0000;font-size:12px}     
</style>
<?php

//127.0.0.1/law/works/ajax/srch_prblm3.php
include('../../xtras/session.php');
include('../../xtras/config.php');
echo '</br>';

   ?>
   
   <center>
       <form id="quick-search" action='../works/ajax/livesearch.php' dir='rtl' method="post" accept-charset="UTF-8" >
   <table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'>
     <?   $sql_gov=mysql_query("select id,gov_name from tbl_gov");
         $sql=mysql_query("select id,client_name from tbl_problems");
	 ?>
   
   <tr> <td width='150px'> <label for ="title">  اسم الموكل   :</label> </td> 

<td width=10%><input type='text' name="client" class="client" list='lkx'>
    <datalist id='lkx'>
       <? while($row = mysql_fetch_array($sql)){
	   $id=$row[0];
	   $client_name=$row[1];
         ?><option value="<?=$client_name;?>"><?=$client_name;?></option><?}?>
	</datalist> 
      </td></tr>
					  
<td width='150px'><label for ="title">  نوع القضيه   :</label></TD>
   <td width=10%> <select name="prblm_type" class="prblm_type"  >   </td> </tr> 
  			
		</table>
		
<div class='abx'></div>





	</form> 
	
	

		<script src="../../xtras/bootstrap/js/jquery-1.11.0.min.js"></script>

     <script type="text/javascript">
     
// $(function(){$("form#quick-search").submit(function(){			
	//	     $.ajax({type:"POST",data: $(this).serialize(),
      //          url: "livesearch.php",
        //        success: function(msg){$(".abx").html(msg);}});
			//	return false;});
				
			 	
	//});
	$('.prblm_type').change(function(){
	//alert("mahmoud");
		 var a = confirm('هل ترغب فى ارسال البيانات');
		 if(a=='1'){
		$("form#quick-search").submit();
			
		}
 	});
 
  </script>	

<script type="text/javascript" src="../../xtras/bootstrap/js/jquery.min.js"></script></script>
<script type="text/javascript">
$(document).ready(function(){
//alert("zanaty");
$(".client").change(function(){
var id=$(this).val();
var dataString = 'client='+ id;
alert(dataString);
$.ajax
({
type: "POST",
url: "../works/ajax/ajax_city3.php",
data: dataString,
cache: false,
success: function(html)
{$(".prblm_type").html(html);} 
});

});

});
</script>