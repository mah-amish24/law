<meta charset="utf-8">
<?php
 include('../../xtras/session.php');
 include('../../xtras/config.php');

 $prblm_cls = $_POST['prblm_cls'];
$prblm_type = $_POST['prblm_type'];
$client_name = $_POST['client'];

$client_sefa = $_POST['client_sefa'];
$client_tel  = $_POST['client_tel'];

$Opponent_name = $_POST['Opponent_name'];
$opt_lawer_name=$_POST['opt_lawer_name'];
$Opponent_sefa = $_POST['Opponent_sefa'];
$Opponent_tel = $_POST['Opponent_tel'];


$prblm_no = $_POST['prblm_no'];
$appeal_no = $_POST['appeal_no'];


$twkl_no = $_POST['twkl_no'];
$cycle_no = $_POST['cycle_no'];
$mhkma = $_POST['mhkma'];
$cmnts = $_POST['cmnts'];




echo'</br>';
$sql_statemanet ="INSERT INTO tbl_problems (prblm_cls,prblm_type,client_name,client_sefa,client_tel,Opponent_name,opt_lawer_name,Opponent_sefa,Opponent_tel,prblm_no,appeal_no,twkl_no,cycle_no,mhkma,cmnts,crt_date)
VALUES('$prblm_cls','$prblm_type','$client_name','$client_sefa','$client_tel','$Opponent_name','$opt_lawer_name','$Opponent_sefa','$Opponent_tel','$prblm_no','$appeal_no','$twkl_no','$cycle_no','$mhkma','$cmnts',now() ) ";
				
//echo  "sql_statemanet >>".$sql_statemanet ;							  
								        mysql_query( $sql_statemanet);
	
 
   echo "<script>   alert(\" تمت عملية ادخال البيانات  بنجاح \");    </script>";
		
?>
