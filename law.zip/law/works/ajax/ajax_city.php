<?php
include('../../xtras/config.php');
 $prblm_cls2=$_POST['prblm_cls2'];

//echo "<script type=\"text/javascript\"> alert(\" mahmoud.$prblm_cls2;\");  </script>";
if($_POST['prblm_cls']){
$prblm_cls=$_POST['prblm_cls'];
//echo "<script type=\"text/javascript\"> alert(\" zanaty\");  </script>";
//echo "<script type=\"text/javascript\"> alert(\" zanaty.$prblm_cls \");  </script>";
$stmnt=" select  id,prblm_name  from  $prblm_cls ";
 $sql=mysql_query($stmnt);

while($row=mysql_fetch_array($sql))
{
$id=$row['id'];
$data=$row['prblm_name'];
echo '<option value="'.$data.'">'.$data.'</option>';

}

		
						
					
}

?>