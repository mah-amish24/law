 <div class='contx'>
		<div class='pagex'>
		<meta charset="utf-8">
		
		<style type="text/css">
.myTable { width:70%; border-collapse:collapse;  }
.myTable td { padding:8px; border:#999 1px solid; }
 
.myTable tr:nth-child(even) {background: #A4D1FF;}
.myTable tr:nth-child(odd) {background: #EAF4FF;}	 
#mmx {text-align:center;} 
body{font-family:arial;}
.preview{width:400px;border:solid 1px #dedede;padding:10px;}
#preview{color:#cc0000;font-size:12px}     
</style>
<?php 
//127.0.0.1/law/works/ajax/insert_prblm.php


include('../../xtras/session.php');
include('../../xtras/config.php');
echo '</br>';

   ?>
   
   <center>
   <form  id="myform"  dir='rtl'> 
   
   <table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'>
     <?   $sql_gov=mysql_query("select id,gov_name from tbl_gov"); 
           $sql=mysql_query("select id,client_name from tbl_problems");	 ?>
   
   <tr> <td width='50px'> <label for ="title">   تصنيف القضايا   :</label> </td>
   <td width=10%><select name="prblm_cls" class="prblm_cls">
         <option selected="selected">-اختار تصنيف القضايا-</option>
           <option value="tbl_problem_family">أسره   </option>
		   <option value="tbl_problem_msdmnr"> جنح   </option>
           <option value="tbl_problem_civil"> مدني  </option>   
		          </td>   </select>	</tr>
				  
<tr><td width='50px'><label for ="title">  نوع القضيه   :</label></TD>
   <td width=10%> <select name="prblm_type" class="prblm_type"> 
<option selected="selected">- اختار نوع القضيه-</option>

  </td> </tr> 
   
   <tr> <td width='150px'> <label for ="title">  اسم الموكل   :</label> </td> 

<td width=10%><input type='text' name="client" class="client" list='lkx'>
    <datalist id='lkx'>
       <? while($row = mysql_fetch_array($sql)){
	   $id=$row[0];
	   $client_name=$row[1];
         ?><option value="<?=$client_name;?>"><?=$client_name;?></option><?}?>
	</datalist> 
      </td></tr>
   
   <!-- <tr> <td width='50px'> <label for ="title">  اسم الموكل </label> </td>   
     <td width=70%> <input type="text" id="client_name" name="client_name" size="40">    </TD></tr>-->
	 
	 <tr><td> <label for ="title">  صفتة </label> </td>   
     <td> <input type="text" id="client_sefa" name="client_sefa" size="40" value='مدعي عليه'>    </TD></tr>
	 
	 <tr><td> <label for ="title">  تليفون  </label> </td>   
     <td> <input type="text" id="client_tel" name="client_tel" size="40">    </TD></TR>
	   
     <tr> <td width='50px'> <label for ="title">  اسم الخصم   :</label> </td>   
     <td width=70%> <input type="text" id="Opponent_name" name=" Opponent_name" size="40" >    </TD></TR>
	 
	 <tr> <td width='50px'> <label for ="title">   محامي الخصم   :</label> </td>   
     <td width=70%> <input type="text" id="opt_lawer_name" name=" opt_lawer_name" size="40" >    </TD></TR>
	 
	  <tr><td> <label for ="title">صفتة</label> </td>   
     <td width=70%> <input type="text" id="Opponent_sefa" name=" Opponent_sefa" size="40" value='مدعي عليه'>    </TD></TR>
	 
	  <tr><td width='50px'> <label for ="title"> تليفون</label> </td>   
     <td width=70%> <input type="text" id="Opponent_tel" name=" Opponent_tel" size="40">    </TD></TR>
	 
	 
	 <tr> <td width='50px'> <label for ="title">  رقم القضيه   :</label> </td>   
     <td width=70%> <input type="text" id="prblm_no" name=" prblm_no" size="40"  >     </TD></TR>
	 
	 <tr> <td width='50px'> <label for ="title">  رقم الاسئناف   :</label> </td>   
     <td width=70%> <input type="text" id="appeal_no" name=" appeal_no" size="40"  >     </TD></TR>
	 
	 <tr> <td width='50px'> <label for ="title">  رقم التوكيل   :</label> </td>   
     <td width=70%> <input type="text" id="twkl_no" name=" twkl_no" size="40"  >     </TD></TR>
	 
	 <tr> <td width='50px'> <label for ="title">  رقم الدائره   :</label> </td>   
     <td width=70%> <input type="text" id="cycle_no" name=" cycle_no" size="40"  >     </TD></TR>
	 
	 <tr> <td width='50px'> <label for ="title">  محكمه    :</label> </td>   
     <td width=70%> <input type="text" id="mhkma" name=" mhkma" size="40" value='قلين' >     </TD></TR>
	 
	 <tr> <td width='50px'> <label for ="title">  ملاحظات   :</label> </td>   
     <td width=70%> <input type="text" id="cmnts" name=" cmnts" size="40"  >     </TD></TR>
	 
	 
   	<tr> <td width='50px'> <label for ="title"> ادخل البيانات     :</label> </td>
       <td width=10px>
	   
	       <!--<input type="button" id="click2" value="...ادخال"   class='v11' >--> 
		   <img src="img/ok.png" alt="Uploading...." name="photoimg" id="photoimg" height="10%" width="15%"/ class='v11'>
		   <input type="reset" id="click" value="...تفريغ"  > 
	   </td> </tr> 
			
		</table>
		
<div class='abx'></div>
	</form> 
	
	

		<script src="../../xtras/bootstrap/js/jquery-1.11.0.min.js"></script>
     <script type="text/javascript">
     //alert('zanaty0');
 $(function(){$("form#myform").submit(function(){
			//alert('zanaty1');
		     $.ajax({type:"POST",data: $(this).serialize(),
                url: "../works/ajax/ajaxinst_cbl.php",
                success: function(msg){$(".abx").html(msg);}});
				return false;});
				
			 	
	});
	$('.v11').click(function(){
	//alert("mahmoud");
		 var a = confirm('هل ترغب فى ارسال البيانات');
		 if(a=='1'){
		$("form#myform").submit();
			
		}
 	});
 
  </script>	

<!--<script type="text/javascript" src="../../xtras/bootstrap/js/jquery.min.js"></script></script>-->
<script type="text/javascript">
$(document).ready(function(){
//alert("zanaty");
$(".prblm_cls").change(function(){
var id=$(this).val();
var dataString = 'prblm_cls='+ id;
//alert(dataString);
$.ajax
({
type: "POST",
url: "../works/ajax/ajax_city.php",
data: dataString,
cache: false,
success: function(html)
{$(".prblm_type").html(html);} 
});

});

});
</script>
<!--
insert_prblm.php
ajax_city.php
ajaxinst_cbl


srch_prblm3.php
livesearch.php
ajax_city3.php
ajxinst_prblm.php

lawer_daily
-->