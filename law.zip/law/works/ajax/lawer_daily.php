
<!--127.0.0.1/law/works/ajax/lawer_daily.php-->
<html xmlns="http://www.w3.org/1999/xhtml" lang="ar" xml:lang="ar">
     <meta http-equiv="content-type" content="text/html; charset=UTF-8">

		<style type="text/css">
.myTable { width:70%; border-collapse:collapse;  }
.myTable td { padding:8px; border:#999 1px solid; }
 
.myTable tr:nth-child(even) {background: #EAF4FF;}
.myTable tr:nth-child(odd) {background: #A4D1FF;}	 
#mmx {text-align:center;} 
body{font-family:arial;}
.preview{width:400px;border:solid 1px #dedede;padding:10px;}
#preview{color:#cc0000;font-size:12px}     
</style>

<?  

include('../../xtras/config.php');
include('../../xtras/session.php');
 $sql=mysql_query("select distinct session_date,session_date  from tbl_first_dgree order by session_date desc ");	 ?>
<form  id="myform"  dir='rtl' accept-charset="UTF-8">
    
    <table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'>       
	<tr><td>  اختار التاريخ لعرض الاجنده</td> 
	<td width=10%>
	<select name="inputField" class="inputField"  > 
	
	<? echo '<option selected="selected">--اختار التاريخ--</option>';
        while($row = mysql_fetch_array($sql)){
	   	   $session_date=$row[1];
	   	   $session_date=$row[1];
         ?><option value="<?=$session_date;?>"><?=$session_date;?></option><?}?>
	
      </td></TR>
 
 </table>
</br>


<table width='500px' cellpadding='1px' cellspacing='2' border='1' dir='rtl' id='mmx' class='myTable'>
	<TR>
	<TD  rowspan="2" >  استعلام حسب </TD> 
	<TD><input type="radio" name="when" value="now"   class='v10'>   اليوم الحالي 	</td>
	<TD><input type="radio" name="when" value="today"   class='v15'>  اليوم التالي 	</td> 
	<td>  <input type='submit' id='click2' value='عرض .....'   class='v11' size='55' >  </TD>
	</TR> 
	
   <TR> 
   <TD><input type="radio" name="when" value="week">  الاسبوع   </td>
   <td><input type="radio" name="when" value="month">  الشهر	</td>    
   <td> <input type='reset' id='click12' value=' Reset.'   class='v12' size='55' > </td>

	</tr>  </table>
 </br>
 <div class='abx'></div>

 </form>
 
 	<script src="../../xtras/bootstrap/js/jquery-1.11.0.min.js"></script>
     <script type="text/javascript">
     //alert('zanaty0');
 $(function(){$("form#myform").submit(function(){
			//alert('zanaty1');
		     $.ajax({type:"POST",data: $(this).serialize(),
                url: "../works/ajax/lawer_daily_ajax.php",
                success: function(msg){$(".abx").html(msg);}});
				return false;});
				
			 	
	});
	$('.inputField').change(function(){
	//alert("mahmoud");
		//var a = confirm('هل ترغب فى ارسال البيانات');
		 //if(a=='1'){
		$("form#myform").submit();
			
	//	}
 	});
 
 $('.v11').click(function(){
	//alert("mahmoud");
		// var a = confirm('هل ترغب فى ارسال البيانات');
		// if(a=='1'){
		$("form#myform").submit();
			
		//}
 	});
 
 
  </script>
