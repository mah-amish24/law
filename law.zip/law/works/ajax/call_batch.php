<?php
include('../../xtras/session.php');
//localhost/law/works/ajax/call_batch.php
system('cmd.exe /c D:\MySQLBackups\mysqlbackup.bat');
?>

