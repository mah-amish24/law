<?php
include('xtras/login.php');//includes login script

?>
       <html lang="en">
        <head>
		<link rel="stylesheet" type="text/css"  href="login/styles/index.css" media="screen" />
		 <script src="//code.jquery.com/jquery-1.10.2.js"></script>
         <script src="//code.jquery.com/ui/1.11.1/jquery-ui.js"></script>
		 
		</head>
        <body>
           
                <div class="grid_5 login">
                    <img class="logo" alt="sesco" src="login/img/LAW_LOGO.png"></img>
					<!--<img class="logo" alt="sesco" src="login/img/mmdo7.png"></img>-->
                   

                    <form id="form" action="" method="post">
                        
						<input id="username" class="user" type="text" placeholder="username" name="username"></input>
                        <div id="UserName_span" style="color:red;font-size:16px;text-align:center"></div>
                        <br> 
						<input id="Password" class="pass" type="password" placeholder="Password" name="password"></input>
                        <div id="Password_span" style="color:red;font-size:16px;text-align:center"></div>
                        <br> 
						<input name="submit" class="log" value="LOGIN" type="submit">
                           <div id="header"><br><span align="center" ><?php echo $error; ?></span></br> </div>
                        
                    </form> 
                </div>
            
             <h5></h5>
        </body>
    </html>
<script>
	$('.login').draggable();
</script>
