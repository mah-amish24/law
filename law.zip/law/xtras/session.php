<?php
//Establishing Connection with Server by passing server_name, user_id and password as a parameter 
$connection = mysql_connect("localhost", "root", "");

//Selecting Database
$db = mysql_select_db("law", $connection);   
                            
session_start();// Starting Session

//Storing session
$user_check=$_SESSION['login_user'];
//echo ">>>user>>>".$user_check;

//SQL query to fetch complete information of user   
$ses_sql=mysql_query("select username from users where username='$user_check'", $connection);
$row = mysql_fetch_assoc($ses_sql);

$login_session =$row['username'];
//echo ">>>login_session>>>".$login_session;
if(!isset($login_session)){

//Closing Connection
mysql_close($connection);
header('Location: ../index.php');//Redirecting to home page 
}
?>