﻿<html>
<head>
<meta charset="utf-8">
<title>Telecom Egypt</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="css/le-frog/jquery-ui-1.10.3.custom.css" rel="stylesheet">
<script src="js/jquery-1.9.1.js"></script>
<script src="js/jquery-ui-1.10.3.custom.js"></script>


<link href="mystyle.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"> 
<link rel="stylesheet" href="css/mystyle.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/styles_me.css" type="text/css" media="screen">

	<?include('config.php');
	include('session.php');
     $tbl=$login_session;
	$id ='8';
	?>
</head>
<body>
	<center>
	 
	<div class='header'>
		<div id='user'><a href="logout.php"><img src='../images/user.png' width='20px'></a> LogOut | <img src='../images/flag.png' width='20px'> Language</div>
		
		<div class='title'>مكتب الاستاذ حسام محمد شتات</div>
		<font color="white"; size="5"> <p>المحامى بالاستئناف العالى ومجلس الدوله </p></font>
		
	</div>
 <!--<div align="right" style="color:white" ><?echo $login_session."  مرحبا   ";?></div> -->
 <div align="center" style="color:white" ><?echo " Welcome    ".$login_session;?></div>
	<!-- ===================menu================================================= -->
	<div class='nav'>
	<table width='1150px' cellpadding='0px' cellspacing='0' border='0' dir='rtl'>
		<tr>
			<td><?include('main_menu.php');?></td>
			<td width='200px;' >
			<img src='../images/se.png' width='18px'>
			<input type='text' class='search' ></td>
			
		</tr>
		
	</table>
		
	</div>
	
	<!-- =====================content==========================================================  -->
	 <div class='contx'>
		<div class='pagex'>
	 
	  
				  
	
	<!--=================================================table data====================================================== -->
		
		  
		
		
		  
		</div>
	 </div>
	 <!-- =========================footer=================================================================== -->
	 <div class='footer'>
		<div id='fotx'>
		جميع الحقوق محفوظة لفريق الاندلس لتطوير البرمجيات 2014-2015<br>
                 برمجة وتصميم م/ محمودالزناتي 01011800592 
		 
		 
		 </div>
	</div>
	 <div class='mod'></div>
	</center>
</body>
</html>

