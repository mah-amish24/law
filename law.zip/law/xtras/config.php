<?php
	
	$con = mysql_pconnect('localhost','root','');
	mysql_select_db('law',$con);
	mysql_query("SET NAMES 'utf8'");
	//mysql_query("SET NAMES utf8"); //IMPORTANT
?>