<?
include('config.php');
$sql = mysql_query("select namex from tbl_menus where lev='1' and state='1' order by id");
?>
<div class="example">
    <ul id="nav">
	 <!-- <li style='padding-top:5px;'><img src='../images/arrow.png'></li>-->
       <?/*while($r=mysql_fetch_array($sql)){?>
			<li><a href='#'><?=$lev1=$r[0];?></a>
				 <?funx1($lev1,$id);?>
			</li>
			 
	   <?}*/?>
	  <!-- <li><a href='../works/ajax/insert_prblm.php'> اضافة  موكل</a> </li>-->
	  <li><a href='#' onclick="$('.pagex').html('Loading...'),$.ajax({url:'<?='../works/ajax/insert_prblm.php';?>',success: function(data){$('.pagex').html(data);}});">اضافة  موكل</a></li>
	  <li><a href='#' onclick="$('.pagex').html('Loading...'),$.ajax({url:'<?='../works/ajax/srch_prblm3.php';?>',success: function(data){$('.pagex').html(data);}});">بحث عن موكل ابتدائي</a></li>
	  <li><a href='#' onclick="$('.pagex').html('Loading...'),$.ajax({url:'<?='../works/ajax/lawer_daily.php';?>',success: function(data){$('.pagex').html(data);}});">اجندة المواعيد</a></li>
	  <li><a href='#' onclick="$('.pagex').html('Loading...'),$.ajax({url:'<?='../works/ajax/show_tbl.php';?>',success: function(data){$('.pagex').html(data);}});">عرض القضايا</a></li>
	  <li><a href='#' onclick="$('.pagex').html('Loading...'),$.ajax({url:'<?='../works/ajax/backup.php';?>',success: function(data){$('.pagex').html(data);}});">حفظ قاعدة البيانات</a></li>
    </ul>
	 
</div>

<?
	function funx1($lev1,$id){
		$sql = mysql_query("select namex from tbl_menus where grp='$lev1' and lev='2' and state='1' order by id ");
		?><ul><?
			while($r2=mysql_fetch_array($sql)){?>
				<li><a href='#' ><?=$lev2=$r2[0];?></a>
					<?funx2($lev2,$id);?>
				</li>
			<?}?>
		</ul>
		
	<?}
?>

<?
	function funx2($lev2,$id){
		$sql3 = mysql_query("select namex,url from tbl_menus where grp='$lev2' and lev='3' and state='1' order by id ");
		$a = mysql_num_rows($sql3);
		if($a>=1){
		?><ul><?
			while($r3=mysql_fetch_array($sql3)){$url=$r3[1];if($url==''){$url='works/empty.php';}?>
				<li>
				<a href='#' onclick="$('.pagex').html('Loading...'),$.ajax({url:'<?=$url;?>',success: function(data){$('.pagex').html(data);}});">
				<?
				 
				if($url!='works/empty.php'){?>
				<img src='../images/ar2.png' width='10px'>
				<?}else{?>
				<img src='../images/ar1.png' width='10px'>
				<?}?>
				<?=$lev3=$r3[0];?>
				</a></li>
			<?}?>
		</ul>
		
	<?}else{echo'';}}
?>

 

